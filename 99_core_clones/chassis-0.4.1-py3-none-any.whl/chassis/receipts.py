"""A receipt for every act: who, when, what, the checks that were run and whether the act was placed. One JSON file per
act under the receipts folder (a face may keep its own subfolder). Receipts are never edited; the audit page is them, in
order.

A check is a row {"check": str, "ok": bool, "says": str[, "flag": bool]} — a flagged check is told, not refused.
`placed = all(c["ok"] or c.get("flag") for c in checks)` is the one rule, and `judge()` applies it."""
from __future__ import annotations

import datetime as dt
import json
import pathlib
import re
import uuid

from . import CONFIG


def judge(checks: list[dict]) -> bool:
    return all(c["ok"] or c.get("flag") for c in checks)


def write(kind: str, who: str, subject: str, checks: list[dict], placed: bool, where: str | pathlib.Path | None = None) -> dict:
    folder = pathlib.Path(where) if where is not None else CONFIG.receipts
    if not folder.is_absolute():
        folder = CONFIG.receipts / folder
    r = {"receipt": str(uuid.uuid4())[:8], "at": dt.datetime.now().isoformat(timespec="seconds"), "act": kind, "by": who,
         "subject": subject, "placed": placed, "checks": checks}
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f"{r['at'].replace(':', '')}_{kind}_{re.sub(r'[^A-Za-z0-9_.-]', '_', subject)[:80]}.json").write_text(json.dumps(r, indent=2))
    return r


def act(kind: str, who: str, subject: str, ok: bool, says: str, where: str | pathlib.Path | None = None) -> dict:
    """The one-check act: a desk's confirm, a run started, a period opened."""
    return write(kind, who, subject, [{"check": kind, "ok": ok, "says": says}], ok, where)


def recent(n: int = 8, where: str | pathlib.Path | None = None) -> list[dict]:
    """The latest receipts, newest first, across every face's folder under the receipts root (or one folder)."""
    root = pathlib.Path(where) if where is not None else CONFIG.receipts
    if not root.is_absolute():
        root = CONFIG.receipts / root
    files = sorted(root.rglob("*.json"), key=lambda p: p.name, reverse=True)[:n] if root.exists() else []
    return [json.loads(f.read_text()) for f in files]


def all_receipts(where: str | pathlib.Path | None = None) -> list[dict]:
    return recent(10**9, where)
