"""Who the face is acting as, what it last said, what the last run printed. One instance per app, not a module global —
two faces in one process (a door page and a desk) must not share a default-who rule.

    session = Session(default=lambda principals: next((p for p in principals if "planner" in p), principals[0]))
    who = session.who(principals())          # the chosen principal, or the default when none is chosen or it has gone
    session.say("entry placed", ok=True)      # the next page shows it once
    flash = session.flash()                   # {"says": ..., "ok": ...} or None
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Session:
    default: Callable[[list[str]], str] = lambda ps: ps[0] if ps else ""
    state: dict = field(default_factory=lambda: {"who": None, "msg": None, "ok": True, "last": None, "run_log": None})

    def who(self, principals: list[str]) -> str:
        if self.state["who"] not in principals:
            self.state["who"] = self.default(principals) if principals else ""
        return self.state["who"]

    def become(self, who: str) -> None:
        self.state["who"] = who

    def say(self, msg: str, ok: bool = True) -> None:
        self.state["msg"], self.state["ok"] = msg, ok

    def flash(self) -> dict | None:
        """What was last said, shown once."""
        msg, ok = self.state["msg"], self.state["ok"]
        self.state["msg"] = None
        return {"says": msg, "ok": ok} if msg else None

    @property
    def last(self) -> dict | None:
        return self.state["last"]

    @last.setter
    def last(self, receipt: dict | None) -> None:
        self.state["last"] = receipt

    @property
    def run_log(self) -> str | None:
        return self.state["run_log"]

    @run_log.setter
    def run_log(self, log: str | None) -> None:
        self.state["run_log"] = log


def default_holder(verb: str, held: Callable[[str], set[str]], avoid: str = "") -> Callable[[list[str]], str]:
    """A default-who rule: the first principal holding `verb` (and whose name does not contain `avoid`), else the first."""
    def pick(principals: list[str]) -> str:
        return next((p for p in principals if verb in held(p) and (not avoid or avoid not in p)), principals[0] if principals else "")
    return pick
