"""The run: the same commands the schedule runs, started from the face, stopping at the first failure, the log kept for
the page. What the run says afterwards is read from the warehouse, never from the face's memory.

    runner = Runner([["uv", "run", "python", "-m", "ingest.pipeline"],
                     ["uv", "run", "sqlmesh", "plan", "prod", "--auto-apply", "--no-prompts"]])
    log = runner.run()                  # "✓ python -m ingest.pipeline\\n✓ sqlmesh plan prod ..." or the failure's tail

`health(q, surface)` reads the build's run-health surface (one row per worklist: name, severity, items, what to do,
whose) if the build has one; a build without one gets an empty list, not an error."""
from __future__ import annotations

import pathlib
import subprocess
from typing import Callable

from . import CONFIG
from .warehouse import Busy, exists


class Runner:
    def __init__(self, commands: list[list[str]] | None = None, cwd: pathlib.Path | None = None, tail: int = 1500):
        self.commands = commands if commands is not None else CONFIG.run_commands
        self.cwd, self.tail = cwd or CONFIG.root, tail

    def run(self) -> str:
        log = []
        for cmd in self.commands:
            r = subprocess.run(cmd, cwd=self.cwd, capture_output=True, text=True)
            shown = " ".join(c for c in cmd if c not in ("uv", "run"))
            log.append(f"{'✓' if r.returncode == 0 else '✗'} {shown}")
            if r.returncode:
                log.append((r.stdout + r.stderr)[-self.tail:]); break
        return "\n".join(log)

    @property
    def ok(self) -> Callable[[str], bool]:
        return lambda log: "✗" not in log


def attention(q: Callable[..., list[dict]], who: str, surface: str = "gold.maintenance_run_health", limit: int = 50) -> list[dict]:
    """Every worklist row routed to this person: for each run-health row with items, the rows of its surface whose
    `whose` names them. Each row comes back with the worklist's name, severity and what to do; the row's own columns
    beside. Nothing here is typed by the face — a row exists because the run produced it."""
    out = []
    for h in health(q, surface):
        if not h.get("items") or not h.get("surface"):
            continue
        try:
            rows = q(f"select * from {h['surface']} where whose like ? limit ?", f"%{who}%", limit)
        except Exception:
            continue
        for r in rows:
            out.append({"name": h["name"], "severity": h["severity"], "what_to_do": h.get("what_to_do"), "surface": h["surface"], "row": r})
    return out


def health(q: Callable[..., list[dict]], surface: str = "gold.maintenance_run_health") -> list[dict]:
    try:
        if not exists(surface):
            return []
        return q(f"select * from {surface} order by case severity when 'STOP' then 0 when 'VERDICT' then 1 else 2 end, name")
    except Busy:
        return []
