"""The warehouse, read only. A connection per question, closed at once, so a run can take the file whenever it needs it.
While a run holds the file, reading says so instead of failing. The face never writes here: what it shows about the
last run is what the run said."""
from __future__ import annotations

import duckdb

from . import CONFIG


class Busy(Exception):
    """The warehouse cannot be read right now; the message says why."""


def q(sql: str, *params) -> list[dict]:
    if not CONFIG.db.exists():
        raise Busy("the warehouse has not been built yet — run the pipeline")
    try:
        con = duckdb.connect(str(CONFIG.db), read_only=True)
    except duckdb.IOException as e:
        raise Busy("a run holds the warehouse; try again in a moment") from e
    try:
        cur = con.execute(sql, list(params))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]
    finally:
        con.close()


def one(sql: str, *params) -> dict | None:
    rows = q(sql, *params)
    return rows[0] if rows else None


def exists(relation: str) -> bool:
    """Whether a schema.table the face would read is there — a page can say 'not built yet' instead of erroring."""
    schema, _, table = relation.partition(".")
    return one("select 1 as ok from information_schema.tables where table_schema = ? and table_name = ?", schema, table) is not None
