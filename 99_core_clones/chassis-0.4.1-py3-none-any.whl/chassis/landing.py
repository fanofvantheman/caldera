"""Files as record. The face is the landing's only writer; the pipeline reads the landing whole on every run; the
history is the files. Two ways a set of files can be a record, and a build chooses — the chassis never defaults:

`LogLanding` — the files are a log. One CSV per act, named by the moment and the actor, placed under
<landing>/<group>/<table>/. Files are never edited or removed; taking something back is a later row that names what
it withdraws. File order is time order, and the load appends every file after the build's generated master.

`SetLanding` — the file set is the state. A file present is a submission; a file removed is a withdrawal; a file
replaced is a resubmission. Presence is judged by the load, not by any row.

Both write the same receipt-ready outcome: the path placed (or removed)."""
from __future__ import annotations

import csv
import datetime as dt
import pathlib
import re
import shutil

from . import CONFIG


def _stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


class LogLanding:
    def __init__(self, group: str, table: str, columns: list[str], root: pathlib.Path | None = None):
        self.group, self.table, self.columns, self._root = group, table, list(columns), root

    @property
    def folder(self) -> pathlib.Path:
        return (self._root or CONFIG.landing) / self.group / self.table

    def place(self, rows: list[dict], who: str) -> pathlib.Path:
        """One act, one file; every column of the contract written, missing ones empty."""
        self.folder.mkdir(parents=True, exist_ok=True)
        path = self.folder / f"{_stamp()}-{_slug(who)}.csv"
        with path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=self.columns)
            w.writeheader()
            for r in rows:
                w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in self.columns})
        return path

    def files(self) -> list[pathlib.Path]:
        """Every file placed, in time order."""
        return sorted(self.folder.glob("*.csv")) if self.folder.is_dir() else []

    def pending(self, built: pathlib.Path | None = None) -> list[pathlib.Path]:
        """Files placed since the warehouse was last built — what the next run will take in."""
        db = built or CONFIG.db
        t = db.stat().st_mtime if db.exists() else 0
        return [p for p in self.files() if p.stat().st_mtime > t]

    def rows(self) -> list[dict]:
        out = []
        for p in self.files():
            with p.open(newline="", encoding="utf-8") as f:
                for i, r in enumerate(csv.DictReader(f), start=2):
                    out.append({**r, "source_file": p.name, "file_row_number": i})
        return out


class SetLanding:
    def __init__(self, folder: pathlib.Path):
        self.folder = pathlib.Path(folder)

    def place(self, src: pathlib.Path, name: str | None = None) -> pathlib.Path:
        """Move a held file into the set; a file of the same name is replaced."""
        self.folder.mkdir(parents=True, exist_ok=True)
        dst = self.folder / (name or pathlib.Path(src).name)
        shutil.move(str(src), str(dst))
        return dst

    def withdraw(self, name: str) -> bool:
        p = self.folder / pathlib.Path(name).name
        existed = p.exists()
        p.unlink(missing_ok=True)
        return existed

    def present(self, name: str) -> bool:
        return (self.folder / pathlib.Path(name).name).exists()

    def files(self) -> list[pathlib.Path]:
        return sorted(self.folder.glob("*.csv")) if self.folder.is_dir() else []
