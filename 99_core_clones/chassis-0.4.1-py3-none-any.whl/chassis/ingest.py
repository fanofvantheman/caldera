"""The landing read into bronze: text rows typed by a declared numeric set, every header column declared (the contract
is the header, not whichever columns happened to carry data), each row stamped with the file and line it came from, the
table replaced whole on every load.

Two resource kinds, matching the two landings:
    set_resource(files, name, numeric)              the file set is the state — every file present, as it stands
    log_resource(master, placed, name, numeric)     the generated master, then every placed file in file order

`dlt` is an optional dependency (`chassis[ingest]`); importing this module without it fails at the resource call, not here."""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable, Iterator


def rows(path: Path, numeric: tuple[str, ...], integer: frozenset[str] = frozenset(), face: str | None = None) -> Iterator[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        for i, row in enumerate(csv.DictReader(f), start=2):
            out = {k: (v if v != "" else None) for k, v in row.items()}
            for col in numeric:
                if out.get(col) is not None:
                    out[col] = int(float(out[col])) if col in integer else float(out[col])
            out["source_file"] = path.name
            out["file_row_number"] = i
            if face is not None:
                out["face"] = face
            yield out


def columns(path: Path, numeric: tuple[str, ...], integer: frozenset[str] = frozenset(), face: bool = False) -> dict:
    with path.open(newline="", encoding="utf-8") as f:
        header = next(csv.reader(f))
    cols = {h: {"data_type": ("bigint" if h in integer else "double") if h in numeric else "text", "nullable": True} for h in header}
    cols["source_file"] = {"data_type": "text"}
    cols["file_row_number"] = {"data_type": "bigint"}
    if face:
        cols["face"] = {"data_type": "text"}
    return cols


def log_resource(master: Path, placed: Iterable[Path], name: str, numeric: tuple[str, ...], integer: frozenset[str] = frozenset()):
    import dlt
    files = [master, *placed]

    def gen():
        for p in files:
            yield from rows(p, numeric, integer)
    return dlt.resource(gen(), name=name, write_disposition="replace", columns=columns(master, numeric, integer))


def set_resource(files: list[tuple[Path, str]], name: str, numeric: tuple[str, ...], integer: frozenset[str] = frozenset(), header_from: Path | None = None):
    """`files` is [(path, face)]: each file present, stamped with the face it came in by."""
    import dlt
    first = header_from or files[0][0]

    def gen():
        for p, face in files:
            yield from rows(p, numeric, integer, face)
    return dlt.resource(gen(), name=name, write_disposition="replace", columns=columns(first, numeric, integer, face=True))
