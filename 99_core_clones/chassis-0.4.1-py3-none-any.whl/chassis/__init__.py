"""chassis — everything in a build's face that does not know which method it carries.

A build (a group close, an integrated plan) is models over a warehouse plus a face people act through. The face's
chrome, its session, how an act becomes a file in the landing, how a receipt is written, who may do what, how a run is
started and read back — none of that depends on the method. This package holds that part once. A build supplies the
pages, the checks, the vocabulary, and the models.

Configure once at app start:

    import chassis
    chassis.configure(root=Path("."), db="data/caldera.duckdb", receipts="data/receipts", landing="data/landing")

Every module reads the configuration; nothing is hard-wired to a build's paths.
"""
from __future__ import annotations

import pathlib
from dataclasses import dataclass, field


@dataclass
class Config:
    root: pathlib.Path = pathlib.Path(".")
    db: pathlib.Path = pathlib.Path("data/warehouse.duckdb")
    receipts: pathlib.Path = pathlib.Path("data/receipts")
    landing: pathlib.Path = pathlib.Path("data/landing")
    run_commands: list[list[str]] = field(default_factory=list)


CONFIG = Config()


def configure(root: str | pathlib.Path = ".", db: str | pathlib.Path | None = None, receipts: str | pathlib.Path | None = None,
              landing: str | pathlib.Path | None = None, run_commands: list[list[str]] | None = None) -> Config:
    """Set the build's paths. Relative paths resolve under `root`."""
    r = pathlib.Path(root).resolve()
    CONFIG.root = r
    if db is not None: CONFIG.db = r / db
    if receipts is not None: CONFIG.receipts = r / receipts
    if landing is not None: CONFIG.landing = r / landing
    if run_commands is not None: CONFIG.run_commands = run_commands
    return CONFIG
