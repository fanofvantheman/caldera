import argparse
import json
import os
import sys
from pathlib import Path

import anthropic
import pandas as pd


# Maps a local P&L chart of accounts to two group-level targets in a single API pass.
#
# Both targets (group L1 and analysis) use the same reference chart — the mapping logic
# differs, not the target list. Group L1 bifurcates on production vs non-production;
# analysis ignores that distinction and classifies all OpEx by cost group.
#
# Non-OpEx items in the analysis mapping carry NON-ANALYSIS — consistent with the
# NON-DEPARTMENTAL sentinel established elsewhere in the consolidation pipeline
# (UNASSIGNED = mapping pending; NON-{X} = definitionally outside that dimension).
#
# Large COAs exceed API output token limits in a single call; source rows are batched
# (default 50) and results concatenated. Two output files are written: a candidates CSV
# (with names, confidence, rationale, review_status for human sign-off) and a canonical
# seed CSV (codes only — the four columns that load into the database).

_SYSTEM = """\
You are a financial chart of accounts mapping specialist.
You will be given a local P&L chart of accounts with five columns — legal entity, account code, account name, analysis code, and analysis name — plus a single reference list used as the target for both mappings.

Mappings are per legal entity. The same account code may map differently across entities — use the legal entity and all four account columns as context.

For each source row, produce two independent mappings using different logic:

--- GROUP L1 MAPPING ---
The group L1 mapping classifies each account by its economic nature within the P&L.
- If the account relates directly to the production of a good (raw materials, direct labour, manufacturing overhead, and similar production costs), map it to the standard cost line. Identify the standard cost line from the reference list by its name — it will be self-evident.
- If the account is an operating expense not related to production, map it to the matching group L1 category based on the nature of the expense.
- If the account is a revenue item, map it to the appropriate revenue line.
- Use both account_name and analysis_name as context — analysis_name often clarifies whether something is production-related.

--- ANALYSIS MAPPING ---
The analysis mapping classifies operating expenses by cost group, ignoring whether costs are production-related.
- For OpEx items: map to the most appropriate cost group in the reference list based on the functional nature of the cost.
- For non-OpEx items (revenue, standard/production cost lines): set analysis_account_code to "NON-ANALYSIS" and analysis_account_name to "NON-ANALYSIS". Set analysis_confidence to "high" — this is a rule, not a judgement.
- Do not apply the production/non-production distinction here — all operating costs map to their cost group regardless of origin.

--- OUTPUT FORMAT ---
Respond with a JSON array only — no preamble, no markdown fences, no trailing text. Each element must have exactly these keys:
  legal_entity            — copied from source (string)
  account_code            — copied from source (string)
  account_name            — copied from source (string)
  analysis_code           — copied from source (string)
  analysis_name           — copied from source (string)
  group_l1_account_code   — best matching group L1 code (string)
  group_l1_account_name   — best matching group L1 name (string)
  group_l1_confidence     — "high", "medium", or "low"
  group_l1_rationale      — one sentence
  analysis_account_code   — best matching analysis code, or "NON-ANALYSIS" for non-OpEx (string)
  analysis_account_name   — best matching analysis name, or "NON-ANALYSIS" for non-OpEx (string)
  analysis_confidence     — "high", "medium", or "low"
  analysis_rationale      — one sentence

Set confidence to "low" when the mapping is ambiguous, no clear match exists, or the account appears to be a control, clearing, suspense, or intercompany account.\
"""

_REQUIRED_KEYS = {
    "legal_entity", "account_code", "account_name", "analysis_code", "analysis_name",
    "group_l1_account_code", "group_l1_account_name", "group_l1_confidence", "group_l1_rationale",
    "analysis_account_code", "analysis_account_name", "analysis_confidence", "analysis_rationale",
}

_SOURCE_COLS = ["legal_entity", "account_code", "account_name", "analysis_code", "analysis_name"]

_SEED_COLS = ["legal_entity", "account_code", "analysis_code", "group_l1_account_code", "analysis_account_code"]


def _load(path: Path, *cols: str) -> pd.DataFrame:
    try:
        df = pd.read_csv(path, encoding="utf-8")
    except UnicodeDecodeError:
        df = pd.read_csv(path, encoding="latin-1")
    except Exception as e:
        raise ValueError(f"{path.name}: {e}") from e
    for col in cols:
        if col not in df.columns:
            raise ValueError(
                f"{path.name}: column '{col}' not found. Available: {list(df.columns)}"
            )
    return df[list(cols)].copy()


def _build_prompt(
    source: pd.DataFrame,
    group_l1: pd.DataFrame, gl1_code: str, gl1_name: str,
    analysis: pd.DataFrame, an_code: str, an_name: str,
) -> str:
    group_block = "\n".join(f"  {r[gl1_code]} | {r[gl1_name]}" for _, r in group_l1.iterrows())
    analysis_block = "\n".join(f"  {r[an_code]} | {r[an_name]}" for _, r in analysis.iterrows())
    source_block = "\n".join(
        f"  {r['legal_entity']} | {r['account_code']} | {r['account_name']} | {r['analysis_code']} | {r['analysis_name']}"
        for _, r in source.iterrows()
    )
    return (
        f"GROUP L1 ACCOUNT REFERENCE:\n{group_block}\n\n"
        f"ANALYSIS ACCOUNT REFERENCE:\n{analysis_block}\n\n"
        f"SOURCE (legal_entity | account_code | account_name | analysis_code | analysis_name):\n{source_block}\n\n"
        "Return the mapping as a JSON array."
    )


def _call_api(
    client: anthropic.Anthropic,
    model: str,
    prompt: str,
    batch_num: int,
    total_batches: int,
) -> list[dict]:
    print(f"  Batch {batch_num}/{total_batches}...", flush=True)
    raw_parts: list[str] = []
    with client.messages.stream(
        model=model,
        max_tokens=16384,
        system=_SYSTEM,
        messages=[{"role": "user", "content": prompt}],
    ) as stream:
        for text in stream.text_stream:
            raw_parts.append(text)

    raw = "".join(raw_parts).strip()
    start = raw.find("[")
    end = raw.rfind("]")
    if start == -1 or end == -1:
        raise ValueError(f"Batch {batch_num}: no JSON array found.\n\nRaw:\n{raw[:500]}")
    raw = raw[start : end + 1]

    try:
        rows = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ValueError(f"Batch {batch_num}: non-JSON output: {e}\n\nRaw:\n{raw[:500]}") from e

    for i, row in enumerate(rows):
        missing = _REQUIRED_KEYS - set(row.keys())
        if missing:
            raise ValueError(f"Batch {batch_num} row {i} missing keys: {missing}")

    return rows


def map_accounts(
    source_path: Path,
    group_l1_path: Path,
    analysis_path: Path,
    candidates_path: Path,
    map_path: Path,
    gl1_code: str, gl1_name: str,
    an_code: str, an_name: str,
    model: str,
    batch_size: int,
) -> int:
    source = _load(source_path, *_SOURCE_COLS).drop_duplicates()
    group_l1 = _load(group_l1_path, gl1_code, gl1_name)
    analysis = _load(analysis_path, an_code, an_name)

    client = anthropic.Anthropic()

    batches = [source.iloc[i : i + batch_size] for i in range(0, len(source), batch_size)]
    total = len(batches)
    print(f"Processing {len(source)} rows in {total} batch(es) of up to {batch_size}...")

    all_rows: list[dict] = []
    for idx, batch in enumerate(batches, 1):
        prompt = _build_prompt(batch, group_l1, gl1_code, gl1_name, analysis, an_code, an_name)
        all_rows.extend(_call_api(client, model, prompt, idx, total))

    candidates = pd.DataFrame(all_rows)
    candidates["review_status"] = ""
    candidates.to_csv(candidates_path, index=False)

    candidates[_SEED_COLS].to_csv(map_path, index=False)

    return len(candidates)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="coa-map",
        description="Map a local COA to group L1 and analysis accounts using Claude.",
    )
    parser.add_argument("--local", required=True, metavar="CSV",
                        help="Source CSV with columns: legal_entity, account_code, account_name, analysis_code, analysis_name")
    parser.add_argument("--group-l1", required=True, metavar="CSV",
                        help="Group L1 account reference CSV")
    parser.add_argument("--analysis", required=True, metavar="CSV",
                        help="Analysis account reference CSV")
    parser.add_argument("--output", required=True, metavar="CSV",
                        help="Candidate mapping CSV (names + confidence + rationale + review_status)")
    parser.add_argument("--map", required=True, metavar="CSV",
                        help="Canonical seed CSV (codes only: legal_entity, account_code, analysis_code, group_l1_account_code, analysis_account_code)")
    parser.add_argument("--group-l1-code", default="group_l1_account_code", metavar="COL",
                        help="Group L1 code column (default: group_l1_account_code)")
    parser.add_argument("--group-l1-name", default="group_l1_account_name", metavar="COL",
                        help="Group L1 name column (default: group_l1_account_name)")
    parser.add_argument("--analysis-code", default="analysis_account_code", metavar="COL",
                        help="Analysis code column (default: analysis_account_code)")
    parser.add_argument("--analysis-name", default="analysis_account_name", metavar="COL",
                        help="Analysis name column (default: analysis_account_name)")
    parser.add_argument("--model", default="claude-opus-4-8", metavar="MODEL",
                        help="Claude model ID (default: claude-opus-4-8)")
    parser.add_argument("--batch-size", type=int, default=50, metavar="N",
                        help="Source rows per API call (default: 50)")
    args = parser.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("Error: ANTHROPIC_API_KEY environment variable not set.", file=sys.stderr)
        sys.exit(1)

    for p in (Path(args.local), Path(args.group_l1), Path(args.analysis)):
        if not p.exists():
            print(f"Error: file not found: {p}", file=sys.stderr)
            sys.exit(1)

    try:
        count = map_accounts(
            Path(args.local), Path(args.group_l1), Path(args.analysis),
            Path(args.output), Path(args.map),
            args.group_l1_code, args.group_l1_name,
            args.analysis_code, args.analysis_name,
            args.model,
            args.batch_size,
        )
        print(f"Mapped {count} rows → {args.output} (candidates) + {args.map} (seed)")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
