"""Map a sender's local codes onto a fixed target list, one subject at a time.

The chart-of-accounts mapping (`coa_map.map`) is one subject with two targets. This module is the
same first pass made generic: any subject — a promotion mechanic, a funding type, a status word, a
customer, a product group, an account — given

  sources   the distinct local codes, each with whatever description the sender gave
  targets   the list the codes must land on (ours), each with a description
  guidance  what the subject is and how to choose, in a sentence or a paragraph

returns, per source code, a proposed target from the list, a confidence (high / medium / low) and
a one-line rationale. The target is constrained to the list by the response schema, so a proposal
can never invent a member; where nothing fits, the target list should carry an "unclassified"
member and the guidance should say when to use it.

The pass proposes; it never decides. A caller writes the proposals somewhere a person reviews them
(accept, or alter to another member of the list) and should call this once per code — an accepted
mapping is applied, not re-proposed.

No credentials, a refusal or an API failure raise `MappingUnavailable` with a plain sentence; the
caller leaves the codes waiting for a person. Nothing here retries beyond the SDK's own retries.

Library use:

    from coa_map.codes import map_codes, credentials_present
    rows = map_codes([{"code": "TPR50", "description": "Half price"}],
                     [{"code": "half_price", "description": "50% off shelf"}, ...],
                     guidance="Map the retailer's tactic to our mechanic.", subject="mechanic")

CLI:

    python -m coa_map.codes --subject mechanic --source codes.csv --targets targets.csv \\
        --guidance "..." --output proposals.csv [--model MODEL]

  codes.csv    columns code, description
  targets.csv  columns code, description
  proposals    columns subject, code, description, target, confidence, rationale

The model defaults to `COA_MAP_MODEL` in the environment, else claude-opus-5-5.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

DEFAULT_MODEL = "claude-opus-5-5"
CONFIDENCE = ("high", "medium", "low")

_SYSTEM = """\
You map a sender's local codes onto a fixed target list for a planning system. You are given the subject being mapped,
guidance on how to choose, the target list (code | description) and the source codes (code | description).

For every source code, choose exactly one target code from the list. Never invent a target. Judge from the code and its
description together; senders abbreviate, so read the description as the stronger evidence.

confidence: "high" when the description plainly names the target's meaning; "medium" when it is the most likely reading
but another target is plausible; "low" when the evidence is thin, ambiguous, or you chose a catch-all member.
rationale: one short sentence a reviewer can check against the source, naming the words that decided it.

Return one item per source code, in the order given, copying the source code exactly."""


class MappingUnavailable(RuntimeError):
    """The first pass did not run: no credentials, a refusal, or the API failed. The message is a plain sentence."""


def credentials_present() -> bool:
    """True when an API credential is in the environment. A caller checks this before promising a first pass."""
    return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))


def _schema(targets: list[str]) -> dict:
    return {
        "type": "object",
        "properties": {
            "mappings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string"},
                        "target": {"type": "string", "enum": targets},
                        "confidence": {"type": "string", "enum": list(CONFIDENCE)},
                        "rationale": {"type": "string"},
                    },
                    "required": ["code", "target", "confidence", "rationale"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["mappings"],
        "additionalProperties": False,
    }


def _prompt(subject: str, guidance: str, sources: list[dict], targets: list[dict]) -> str:
    t = "\n".join(f"  {r['code']} | {r.get('description') or ''}" for r in targets)
    s = "\n".join(f"  {r['code']} | {r.get('description') or ''}" for r in sources)
    return f"SUBJECT: {subject}\n\nGUIDANCE:\n{guidance}\n\nTARGET LIST (code | description):\n{t}\n\nSOURCE CODES (code | description):\n{s}"


def map_codes(sources: list[dict], targets: list[dict], guidance: str, subject: str = "code", *,
              model: str | None = None, client=None, effort: str = "medium") -> list[dict]:
    """Propose a target for each source code. Returns [{code, target, confidence, rationale}], one per distinct source
    code, in source order. Raises MappingUnavailable when the pass cannot run; ValueError on bad inputs."""
    seen, src = set(), []
    for r in sources:
        if r["code"] not in seen:
            seen.add(r["code"]); src.append(r)
    if not src:
        return []
    codes = [r["code"] for r in targets]
    if not codes:
        raise ValueError("the target list is empty")
    if client is None and not credentials_present():
        raise MappingUnavailable("no API key in the environment — the first pass did not run")
    try:
        import anthropic
    except ImportError as e:                                    # pragma: no cover - a dependency of the wheel
        raise MappingUnavailable(f"the Anthropic SDK is not installed ({e})") from e
    client = client or anthropic.Anthropic()
    try:
        with client.messages.stream(
            model=model or os.environ.get("COA_MAP_MODEL") or DEFAULT_MODEL,
            max_tokens=16000,
            system=_SYSTEM,
            output_config={"effort": effort, "format": {"type": "json_schema", "schema": _schema(codes)}},
            messages=[{"role": "user", "content": _prompt(subject, guidance, src, targets)}],
        ) as stream:
            msg = stream.get_final_message()
    except anthropic.APIConnectionError as e:
        raise MappingUnavailable(f"the mapping service could not be reached ({e.__class__.__name__})") from e
    except anthropic.AuthenticationError as e:
        raise MappingUnavailable("the API key was refused — the first pass did not run") from e
    except anthropic.APIStatusError as e:
        raise MappingUnavailable(f"the mapping service answered {e.status_code} — the first pass did not run") from e
    if msg.stop_reason == "refusal":
        raise MappingUnavailable("the mapping service declined the request")
    if msg.stop_reason == "max_tokens":
        raise MappingUnavailable("the answer was cut off — map fewer codes per call")
    text = next((b.text for b in msg.content if b.type == "text"), "")
    try:
        rows = json.loads(text)["mappings"]
    except (json.JSONDecodeError, KeyError, TypeError) as e:
        raise MappingUnavailable(f"the answer was not the shape asked for ({e})") from e
    by_code = {r["code"]: r for r in rows if r.get("target") in codes and r.get("confidence") in CONFIDENCE}
    return [{"code": s["code"], "target": by_code[s["code"]]["target"], "confidence": by_code[s["code"]]["confidence"],
             "rationale": by_code[s["code"]]["rationale"].strip()} for s in src if s["code"] in by_code]


def _read(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if rows and not {"code", "description"} <= set(rows[0]):
        raise ValueError(f"{path.name}: columns code and description are required; found {list(rows[0])}")
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(prog="coa-map-codes", description="Map local codes onto a target list using Claude, one subject at a time.")
    ap.add_argument("--subject", required=True, help="what is being mapped, e.g. mechanic, funding_type, customer")
    ap.add_argument("--source", required=True, metavar="CSV", help="local codes: columns code, description")
    ap.add_argument("--targets", required=True, metavar="CSV", help="the target list: columns code, description")
    ap.add_argument("--guidance", required=True, help="how to choose, in a sentence or a paragraph")
    ap.add_argument("--output", required=True, metavar="CSV", help="proposals: subject, code, description, target, confidence, rationale")
    ap.add_argument("--model", default=None, help=f"Claude model id (default: $COA_MAP_MODEL, else {DEFAULT_MODEL})")
    args = ap.parse_args()
    try:
        src, tgt = _read(Path(args.source)), _read(Path(args.targets))
        out = map_codes(src, tgt, args.guidance, args.subject, model=args.model)
    except (ValueError, OSError, MappingUnavailable) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    desc = {r["code"]: r.get("description", "") for r in src}
    with Path(args.output).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["subject", "code", "description", "target", "confidence", "rationale"])
        w.writeheader()
        for r in out:
            w.writerow({"subject": args.subject, "description": desc.get(r["code"], ""), **r})
    print(f"Proposed {len(out)} of {len(desc)} codes → {args.output}")


if __name__ == "__main__":
    main()
