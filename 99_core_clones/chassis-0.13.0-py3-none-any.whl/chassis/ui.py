"""The page shell every face shares: one stylesheet, one navigation, one vocabulary. A page is a body; the shell is here.

The product is a list of **processes** (the register a build declares — a plan, a close, a financial plan). Each has
**areas**; each area has **sections**, which are pages. A section names the verbs that make it relevant; a person sees
the sections whose verbs they hold, the areas that still have a section, the processes that still have an area. The
role is the gateway: the same product shows a planner their layers and a reader the readings, and shows nobody a
process they do not touch. A section with no verbs is for everyone who can see the face at all.

Across the top: the processes this person reaches. Down the side: the active process's areas, the one you are in
open, another unfolding on a slowed hover or staying open once clicked — only the active context is in the sidebar; the
other processes are across the top. A page names its section; area and process follow. The home page's sidebar is the
person's workspace: the sections of the home page itself.

    SHELL = Shell(brand="Caldera", strapline="integrated planning", home="plan.home", who="select", processes=[
        Process("ibp", "Integrated planning", [
            Area("demand", "Demand", [Section("demand", "Demand plan", "plan.demand", verbs=["read.plan"]), ...]),
        ]),
    ])
    SHELL.page(body, title=..., active="demand", who=who, held=roles.actions_held(who), flash=..., principals=...)

The navigation is process → area → entry and never deeper. An object with several views is **one entry that opens on
tabs**: `Section(key, label, endpoint, tabs=[Tab(key, label, endpoint, args, verbs), …])`. A tab is visible on the same
rule an entry is — any one of its verbs — and an entry with tabs is visible when any of its tabs is and opens on the
first of them the person sees. A page names its tab as `active`; the sidebar marks the entry and the shell draws the
tabs under the page's title. An entry without tabs is exactly what it was.

`Shell(links=[(label, endpoint), …])` offers a few pages to everyone in the top bar after the processes — a map of the
whole, say — that belong to no process.

**Context** is the set of selections that mean the same thing wherever they apply — a version, a year, a node of a
structure. The build declares them once, `Shell(context=[Choice(key, label, options, default), …])`; they are chosen once,
in a block at the top of the left navigation, held in the page's address (`?key=value`) and carried on every address the
face builds (`create_app` adds the ones set to every `url_for`), so a link sent opens on the same context. `options(who,
chosen)` is the build's list for this person — bounded by their assignments — given what is chosen before it; `default`
is the value with none chosen (the first option otherwise). An entry or tab declares the keys its page applies,
`Section(…, uses=("version", "customer"))` (a tab inherits its entry's); a page outside the register passes `uses=` to
`page()`. The block marks a selection the page does not apply, rather than appear to honour it, and one outside the
person's options. Pages read the values with `shell.chosen(who)`; a page's own GET form keeps them with
`{{ context_fields() }}`. The context is not a level of the menu.

A person chooses the face's colour scheme in the top bar. A scheme re-sets the stylesheet's colour tokens and nothing
else; the choice is kept per person in one browser cookie (a map of person → scheme), so the room remembers each person's
choice across restarts and switching who you act as switches the scheme with them. `Shell(schemes=...)` narrows or
renames the set; the keys must be schemes the stylesheet defines.

A client's identity is a **skin**, declared once by the build: `Shell(skin={"primary": "#0b5", "secondary": …, "bar": …})`,
`primary` alone being enough. Scheme and skin are two axes with two owners: the scheme (the person's) sets the tonal
tokens, the skin (the client's) sets the stylesheet's object tokens — the wordmark, the top bar and its text, the
sidebar ground, what is selected or primary, the emphasis edge, the chart series — and nothing else. Every object
token is derived from the declared colours by fixed rules (`derive`), so the same colours always produce the same face:
accent, wordmark, edge and the first series from primary; the second series from secondary; the bar from bar; each
on-colour black or white, whichever contrasts more. Per scheme, an object colour that fails 3:1 against that scheme's
ground (4.5:1 for the wordmark, which is text) falls back to its tonal default in that scheme, and the generated
stylesheet says so. State marks, verdict glyphs, severity, matrix cells, totals and struck rows read only the tonal
tokens and cannot be skinned: identity is coloured, status never is. With no skin the page is exactly what it was.
"""
from __future__ import annotations

import pathlib
import re
from dataclasses import dataclass, field
from typing import Callable

from urllib.parse import parse_qsl, urlencode

from flask import g, has_request_context, render_template_string, request, url_for
from markupsafe import Markup, escape

from .warehouse import Busy

SCHEMES = [("paper", "Paper"), ("night", "Night"), ("slate", "Slate"), ("contrast", "Contrast")]
SCHEME_COOKIE = "face_schemes"
STYLESHEET = pathlib.Path(__file__).parent / "static" / "face.css"
SKIN_KEYS = ("primary", "secondary", "bar")
_HEX = re.compile(r"#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})")


def _rgb(c: str) -> tuple[int, int, int]:
    c = c.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def _luminance(c: str) -> float:
    def ch(v: int) -> float:
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(v) for v in _rgb(c))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a: str, b: str) -> float:
    """The WCAG contrast ratio of two hex colours, 1 to 21."""
    la, lb = sorted((_luminance(a), _luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def on_colour(c: str) -> str:
    """Black or white, whichever has the higher contrast against `c`."""
    return "#000000" if contrast(c, "#000000") >= contrast(c, "#ffffff") else "#ffffff"


def _mix(a: str, b: str, t: float) -> str:
    """`a` over `b` at weight t, as hex."""
    return "#" + "".join(f"{round(x * t + y * (1 - t)):02x}" for x, y in zip(_rgb(a), _rgb(b)))


def scheme_grounds(css: str | None = None) -> dict[str, dict[str, str]]:
    """Each scheme's tonal colour tokens as the stylesheet defines them (the base `:root` block is the first scheme,
    every `[data-scheme=…]` block overrides it) — read from the shipped stylesheet so there is one source."""
    css = css if css is not None else STYLESHEET.read_text(encoding="utf-8")
    def tokens(block: str) -> dict[str, str]:
        return {k: v.strip() for k, v in re.findall(r"--([a-z-]+):\s*(#[0-9a-fA-F]{3,6})\b", block)}
    base_m = re.search(r":root\{(.*?)\}", css, re.S)
    base = tokens(base_m.group(1)) if base_m else {}
    out = {"": base}
    for key, block in re.findall(r":root\[data-scheme=([a-z0-9_-]+)\]\{(.*?)\}", css, re.S):
        out[key] = {**base, **tokens(block)}
    return out


def derive(skin: dict[str, str], schemes: list[tuple[str, str]], css: str | None = None) -> dict:
    """Every object token for every scheme, from the declared colours, by fixed rules. Returns
    {"tokens": {scheme: {token: value}}, "header": {scheme: {...}}, "fallbacks": [(scheme, token, ratio, needed)]}.
    A value is a hex colour or `var(--tonal)` — the default it fell back to."""
    grounds = scheme_grounds(css)
    p, s2, bar = skin.get("primary"), skin.get("secondary"), skin.get("bar")
    out: dict = {"tokens": {}, "header": {}, "fallbacks": []}
    for key, _ in schemes:
        g = grounds.get(key) or grounds[""]
        paper, panel, soft = g.get("paper", "#ffffff"), g.get("panel", "#ffffff"), g.get("soft", "#ffffff")
        bar_ground = bar or panel
        t: dict[str, str] = {}
        def pick(token: str, colour: str, against: list[str], need: float, default: str) -> str:
            ratio = min(contrast(colour, x) for x in against)
            if ratio >= need:
                return colour
            out["fallbacks"].append((key, token, round(ratio, 2), need))
            return default
        if bar:
            t["bar"], t["on-bar"] = bar, on_colour(bar)
        if p:
            t["accent"] = pick("accent", p, [paper, panel, soft], 3.0, "var(--ink)")
            t["on-accent"] = on_colour(p) if t["accent"] == p else "var(--paper)"
            t["brand"] = pick("brand", p, [bar_ground], 4.5, "var(--on-bar)" if bar else "var(--ink)")
            t["edge"] = pick("edge", p, [panel, soft], 3.0, "var(--ink)")
            t["series-1"] = pick("series-1", p, [panel], 3.0, "var(--ink)")
        if s2:
            t["series-2"] = pick("series-2", s2, [panel], 3.0, "var(--muted)")
        out["tokens"][key] = t
        h: dict[str, str] = {}
        if bar:
            h["muted"] = _mix(t["on-bar"], bar, 0.68)
            accent = t.get("accent", g.get("ink", "#000000"))
            if not accent.startswith("#") or contrast(accent, bar) < 3.0:
                h["accent"] = "var(--on-bar)"     # the active process's underline sits on the bar: it reads the bar's text there
        out["header"][key] = h
    return out


def skin_css(skin: dict[str, str] | None, schemes: list[tuple[str, str]], css: str | None = None) -> str:
    """The skin as a stylesheet: per scheme, the object tokens it sets and the fallbacks it states. Empty with no skin."""
    if not skin:
        return ""
    d = derive(skin, schemes, css)
    lines = [f"/* skin: {', '.join(f'{k} {skin[k]}' for k in SKIN_KEYS if skin.get(k))} — object tokens derived by rule, per scheme */"]
    for key, ratio_scheme, ratio, need in [(f[0], f[1], f[2], f[3]) for f in d["fallbacks"]]:
        lines.append(f"/* {key}: --{ratio_scheme} falls back to its default ({ratio}:1 against the ground, {need:g}:1 needed) */")
    for key, _ in schemes:
        sel = f":root[data-scheme={key}]"
        t = d["tokens"][key]
        if t:
            lines.append(sel + "{" + ";".join(f"--{k}:{v}" for k, v in t.items()) + "}")
        if t.get("accent", "").startswith("#"):
            lines.append(f"{sel} button.primary:hover{{background:var(--accent);border-color:var(--accent);filter:brightness(.88)}}")
        h = d["header"][key]
        if "accent" in h:
            lines.append(f"{sel} header.top{{--accent:{h['accent']}}}")
        if "muted" in h:
            lines.append(f"{sel} header.top nav.areas a,{sel} header .who,{sel} header form.who,{sel} header form.scheme,{sel} .brand small{{color:{h['muted']}}}")
            lines.append(f"{sel} header.top nav.areas a:hover,{sel} header.top nav.areas a.active,{sel} header .who b,{sel} header form.who a{{color:var(--on-bar)}}")
            lines.append(f"{sel} header.top{{border-bottom-color:transparent}}")
    return "\n".join(lines)


def schemes_chosen(cookie: str | None) -> dict[str, str]:
    """The cookie's person → scheme map; anything unreadable is no choice."""
    try:
        return dict(parse_qsl(cookie or "", keep_blank_values=True))
    except ValueError:
        return {}


def schemes_cookie(chosen: dict[str, str]) -> str:
    return urlencode(chosen)


@dataclass
class Choice:
    """One selection of the context: chosen once in the navigation's block, carried on every address, read by every page
    that applies it. `options(who, chosen)` → [{"value", "label", "depth"?}], bounded by the person, given the choices
    declared before this one; `default(who, chosen, options)` → the value with none chosen (the first option otherwise);
    `note(who, options)` → one line under the list, or None. `strict`: a value the address carries that is not offered is
    replaced by the default (a year the version does not have); otherwise it is kept and the block says it is not offered
    (a link to a node outside the person's assignments still opens on it). `known(value)` → whether a value exists at all:
    one it does not know (a mistyped code) is replaced by the default, and the block says the value was not recognised —
    "not offered" is kept for a real value outside the person's choices."""
    key: str
    label: str
    options: Callable[[str | None, dict], list[dict]]
    default: Callable[[str | None, dict, list[dict]], str | None] | None = None
    note: Callable[[str | None, list[dict]], str | None] | None = None
    strict: bool = False
    known: Callable[[str], bool] | None = None


@dataclass
class Tab:
    """One view of an entry's object: a page, shown on the same rule a section is — any one of its verbs, or everyone."""
    key: str
    label: str
    endpoint: str
    args: dict = field(default_factory=dict)
    verbs: list[str] = field(default_factory=list)
    uses: tuple[str, ...] | None = None                 # the context keys its page applies; None: its entry's

    def visible(self, held: set[str] | None) -> bool:
        return held is None or not self.verbs or any(v in held for v in self.verbs)


@dataclass
class Section:
    key: str
    label: str
    endpoint: str
    args: dict = field(default_factory=dict)
    verbs: list[str] = field(default_factory=list)      # any one of these makes the section visible; none = everyone
    tabs: list[Tab] = field(default_factory=list)       # an object with several views is one entry that opens on tabs
    uses: tuple[str, ...] = ()                          # the context keys its page applies (its tabs', unless they say)

    def uses_of(self, key: str | None) -> tuple[str, ...]:
        t = next((t for t in self.tabs if t.key == key), None)
        return t.uses if t is not None and t.uses is not None else self.uses

    def shown_tabs(self, held: set[str] | None) -> list[Tab]:
        return [t for t in self.tabs if t.visible(held)]

    def visible(self, held: set[str] | None) -> bool:
        """With tabs, an entry is visible when any of its tabs is; without, on its own verbs."""
        if self.tabs:
            return bool(self.shown_tabs(held))
        return held is None or not self.verbs or any(v in held for v in self.verbs)

    def owns(self, key: str | None) -> bool:
        return key == self.key or any(t.key == key for t in self.tabs)

    def target(self, held: set[str] | None) -> tuple[str, dict]:
        """Where the entry opens for this person: its first visible tab, or its own page."""
        shown = self.shown_tabs(held)
        return (shown[0].endpoint, shown[0].args) if shown else (self.endpoint, self.args)

    def href(self, held: set[str] | None) -> str:
        endpoint, args = self.target(held)
        return url_for(endpoint, **args)


@dataclass
class Area:
    key: str
    label: str
    sections: list[Section]

    def shown(self, held: set[str] | None) -> list[Section]:
        return [s for s in self.sections if s.visible(held)]


@dataclass
class Process:
    key: str
    label: str
    areas: list[Area]
    says: str = ""                                      # one line on what the process is, for a role's home page

    def shown(self, held: set[str] | None) -> list[tuple[Area, list[Section]]]:
        out = []
        for a in self.areas:
            secs = a.shown(held)
            if secs:
                out.append((a, secs))
        return out


HEAD = """<!doctype html><html lang="en" data-scheme="{{ scheme }}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }} — {{ shell.brand }}</title><link rel="stylesheet" href="{{ url_for('static', filename='face.css') }}">{% if skin_css %}<style>{{ skin_css|safe }}</style>{% endif %}</head>
<body><header class="top"><a class="brand" href="{{ url_for(shell.home) }}">{{ shell.brand }}<small>{{ shell.strapline }}</small></a>
<nav class="areas">{% for p in nav.processes %}<a href="{{ p.href }}" class="{{ 'active' if p.active }}">{{ p.label }}</a>{% endfor %}{% for l in nav.links %}<a href="{{ l.href }}" class="link {{ 'active' if l.active }}">{{ l.label }}</a>{% endfor %}</nav>
{% if shell.who == 'select' and principals %}<form class="who" method="post" action="{{ url_for(shell.whoami) }}"><a href="{{ url_for(shell.whoami) }}" title="change who you are">acting as</a>
<select name="who" onchange="this.form.submit()">{% for p in principals %}<option value="{{ p }}" {{ 'selected' if p == who }}>{{ p }}</option>{% endfor %}</select>
<input type="hidden" name="next" value="{{ request.full_path if request.query_string else request.path }}"></form>
{% else %}<span class="who">{% if who %}signed in as <b>{{ who }}</b>{% endif %}</span>{% endif %}
{% if shell.schemes|length > 1 %}<form class="scheme" method="post" action="{{ url_for(shell.scheme) }}"><label for="scheme">scheme</label>
<select id="scheme" name="scheme" onchange="this.form.submit()">{% for k, label in shell.schemes %}<option value="{{ k }}" {{ 'selected' if k == scheme }}>{{ label }}</option>{% endfor %}</select>
<input type="hidden" name="who" value="{{ who or '' }}"><input type="hidden" name="next" value="{{ request.full_path if request.query_string else request.path }}"><noscript><button>set</button></noscript></form>{% endif %}</header>
<div class="shell"><aside class="side">
{% if context_block %}<form class="context" method="get" action="{{ request.path }}"><div class="ctx-head">Context</div>
{% for c in context_block.choices %}<label class="{{ '' if c.applies else 'unused' }}"><span>{{ c.label }}</span><select name="{{ c.key }}">{% for o in c.options %}<option value="{{ o.value }}" {{ 'selected' if o.value == c.value }}>{{ ' ' * (o.depth or 0) }}{{ o.label }}</option>{% endfor %}{% if c.value and not c.offered %}<option value="{{ c.value }}" selected>{{ c.value }}</option>{% endif %}</select>
{% if c.unknown %}<small>‘{{ c.unknown }}’ was not recognised — showing {{ (c.options|selectattr('value', 'equalto', c.value)|map(attribute='label')|first) or c.value or 'the default' }}</small>{% elif not c.applies %}<small>not used on this page</small>{% elif c.value and not c.offered %}<small>not among the choices offered to you</small>{% elif c.note %}<small>{{ c.note }}</small>{% endif %}</label>{% endfor %}
{% for k, v in context_block.keep %}<input type="hidden" name="{{ k }}" value="{{ v }}">{% endfor %}<button>Apply</button>{% if context_block.down %}<small class="ctx-down">{{ context_block.down }}</small>{% endif %}</form>{% endif %}
<nav>{% for g in nav.groups %}<div class="area {{ 'active' if g.active }}"><button type="button" class="group" onclick="this.parentNode.classList.toggle('open')">{{ g.label }}</button>
<div class="sections">{% for s in g.sections %}<a href="{{ s.href }}" class="{{ 'active' if s.active }}">{{ s.label }}</a>{% endfor %}</div></div>{% endfor %}</nav>
</aside>
<main{% if width %} style="--width:{{ width }}"{% endif %}>{% if flash %}<div class="flash {{ 'bad' if not flash.ok }}">{{ flash.says }}</div>{% endif %}
"""
TABS = """<nav class="tabs">{% for t in entry_tabs %}<a href="{{ t.href }}" class="{{ 'active' if t.active }}">{{ t.label }}</a>{% endfor %}</nav>"""
FOOT = """
</main></div></body></html>"""


@dataclass
class Shell:
    brand: str
    strapline: str
    home: str                      # endpoint of the wordmark's link — the role's home page
    processes: list[Process] = field(default_factory=list)
    who: str = "label"             # "label" | "select"
    whoami: str = "whoami"         # endpoint the acting-as selector posts to, when who == "select"
    workspace: list[tuple[str, str]] = field(default_factory=lambda: [("My attention", "#attention"), ("My planning", "#planning")])
                                   # the home page's own sections — what the sidebar shows there, since only the active context shows
    schemes: list[tuple[str, str]] = field(default_factory=lambda: list(SCHEMES))
                                   # the colour schemes a person may choose, the first the default; one entry hides the control
    scheme: str = "scheme"         # endpoint the scheme control posts to
    skin: dict[str, str] | None = None
                                   # the client's colours — {"primary": "#hex", "secondary": …, "bar": …}; sets object tokens only
    links: list[tuple[str, str]] = field(default_factory=list)
                                   # (label, endpoint) pages offered in the top bar after the processes, to everyone — a map, a guide
    context: list[Choice] = field(default_factory=list)
                                   # the selections that mean the same on every page: chosen once, carried on every address

    def __post_init__(self):
        if self.skin:
            unknown = set(self.skin) - set(SKIN_KEYS)
            bad = [k for k, v in self.skin.items() if not _HEX.fullmatch(str(v or ""))]
            if unknown or bad or not self.skin.get("primary"):
                raise ValueError(f"a skin declares primary (and optionally secondary, bar) as #hex colours; got {self.skin}")
        self._skin_css = skin_css(self.skin, self.schemes)

    def scheme_of(self, who: str | None) -> str:
        """This person's chosen scheme, read from the request's cookie; the first scheme when none is chosen."""
        keys = [k for k, _ in self.schemes]
        chosen = schemes_chosen(request.cookies.get(SCHEME_COOKIE)).get(who or "")
        return chosen if chosen in keys else keys[0]

    def locate(self, section_key: str | None) -> tuple[Process | None, Area | None]:
        for p in self.processes:
            for a in p.areas:
                if any(s.owns(section_key) for s in a.sections):
                    return p, a
        return None, None

    def reach(self, held: set[str] | None) -> list[tuple[Process, list[tuple[Area, list[Section]]]]]:
        """What this person sees: every process with at least one visible area, each with its visible sections."""
        out = []
        for p in self.processes:
            areas = p.shown(held)
            if areas:
                out.append((p, areas))
        return out

    def _nav(self, active: str | None, held: set[str] | None) -> dict:
        proc, _ = self.locate(active)
        reach = self.reach(held)
        if proc is None and reach:
            proc = reach[0][0]
        processes = [dict(key=p.key, label=p.label, href=areas[0][1][0].href(held), active=proc is not None and p.key == proc.key)
                     for p, areas in reach]
        groups = []
        if active is None:
            # the home page: only the active context shows, and here that is the person's own workspace
            groups.append(dict(key="workspace", label="My workspace", active=True,
                               sections=[dict(key=href, label=label, href=href, active=False) for label, href in self.workspace]))
            for pr in processes:
                pr["active"] = False
            return dict(processes=processes, groups=groups)
        for p, areas in reach:
            if proc is None or p.key != proc.key:
                continue
            for a, secs in areas:
                groups.append(dict(key=a.key, label=a.label, active=any(s.owns(active) for s in secs),
                                   sections=[dict(key=s.key, label=s.label, href=s.href(held), active=s.owns(active)) for s in secs]))
        return dict(processes=processes, groups=groups)

    # ---- the context ----
    def context_keys(self) -> list[str]:
        return [c.key for c in self.context]

    def _resolve(self, who: str | None) -> tuple[dict, dict]:
        """(chosen values, per key the options offered) — each choice resolved in order, from the address or its default.
        Once per request and person."""
        memo = g.setdefault("_chassis_context", {})
        if who not in memo:
            chosen: dict = {}; offered: dict = {}; unknown: dict = {}
            for c in self.context:
                opts = c.options(who, dict(chosen))
                v = request.args.get(c.key) or None
                if v is not None and not any(o["value"] == v for o in opts):
                    if c.known is not None and not c.known(v):
                        unknown[c.key], v = v, None
                    elif c.strict:
                        v = None
                if v is None:
                    v = c.default(who, dict(chosen), opts) if c.default else (opts[0]["value"] if opts else None)
                chosen[c.key], offered[c.key] = v, opts
            memo[who] = (chosen, offered, unknown)
        return memo[who][:2]

    def unrecognised(self, who: str | None) -> dict:
        """The values the address carried that no choice knows, by key — replaced by the default on this request."""
        self._resolve(who)
        return dict(g.get("_chassis_context", {}).get(who, ({}, {}, {}))[2])

    def chosen(self, who: str | None) -> dict:
        """The context in force for this person on this request: {key: value}."""
        return dict(self._resolve(who)[0])

    def uses_of(self, active: str | None) -> tuple[str, ...]:
        for p in self.processes:
            for a in p.areas:
                for s in a.sections:
                    if s.owns(active):
                        return s.uses_of(active)
        return ()

    def context_block(self, who: str | None, uses: tuple[str, ...]) -> dict | None:
        if not self.context:
            return None
        keys = set(self.context_keys())
        keep = [(k, v) for k, v in request.args.items(multi=True) if k not in keys and v != ""]
        try:
            chosen, offered = self._resolve(who)
        except Busy as e:                  # the warehouse is busy: the block holds what the address says, nothing to choose from
            items = [dict(key=c.key, label=c.label, value=request.args.get(c.key), options=[], offered=True, applies=c.key in uses, note=None)
                     for c in self.context]
            return dict(choices=items, keep=keep, down=str(e))
        items = []
        for c in self.context:
            opts, v = offered[c.key], chosen[c.key]
            items.append(dict(key=c.key, label=c.label, value=v, options=opts, offered=v is None or any(o["value"] == v for o in opts),
                              applies=c.key in uses, note=c.note(who, opts) if c.note else None, unknown=self.unrecognised(who).get(c.key)))
        return dict(choices=items, keep=keep, down=None)

    def tabs_of(self, active: str | None, held: set[str] | None) -> list[dict]:
        """The tabs of the entry the page belongs to, as this person sees them; none when the entry has one view."""
        for p in self.processes:
            for a in p.areas:
                for s in a.sections:
                    if s.tabs and s.owns(active):
                        shown = s.shown_tabs(held)
                        return [dict(key=t.key, label=t.label, href=url_for(t.endpoint, **t.args), active=t.key == active) for t in shown] if len(shown) > 1 else []
        return []

    def page(self, body: str, **ctx) -> str:
        for k in ("who", "width", "active", "flash", "principals", "held"):
            ctx.setdefault(k, None)
        ctx["nav"] = self._nav(ctx["active"], ctx["held"])
        ctx["nav"]["links"] = [dict(label=label, href=url_for(ep), active=request.endpoint == ep) for label, ep in self.links]
        tabs = self.tabs_of(ctx["active"], ctx["held"])
        if tabs:
            # the shell draws the entry's tabs under the page's title (after its first heading, or at the top)
            ctx["entry_tabs"] = tabs
            body = body.replace("</h1>", "</h1>" + TABS, 1) if "</h1>" in body else TABS + body
        uses = ctx.pop("uses", None)
        ctx["context_block"] = self.context_block(ctx["who"], tuple(uses) if uses is not None else self.uses_of(ctx["active"]))
        ctx.setdefault("scheme", self.scheme_of(ctx["who"]))
        ctx["skin_css"] = self._skin_css
        ctx["shell"] = self
        return render_template_string(HEAD + body + FOOT, **ctx)


def context_fields(keys: list[str]) -> Markup:
    """Hidden inputs carrying the context set in the address — for a page's own GET form, which would otherwise drop it."""
    if not has_request_context():
        return Markup("")
    return Markup("".join(f'<input type="hidden" name="{escape(k)}" value="{escape(request.args[k])}">' for k in keys if request.args.get(k)))
