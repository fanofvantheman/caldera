/* Typing into a view without a run (chassis.working). Enter, Tab or leaving an input posts that one cell; the reply is
   the parts of the view the edit changed, each an element with an id, swapped in place. The cursor stays where it is —
   Enter keeps it in the cell, and an element repainted under it is found again (by name, by id, or by its place in the
   part) — and whatever is half-typed in the cell it is in survives the swap. Escape puts back the value shown. Posts go
   one at a time, in the order typed.

   A form submitted on the page (a Save, a Discard) waits: any cell typed and not yet sent is sent, every post still
   going is let finish, and only then does the form go — so the last figure typed is always in what the form acts on.

     <div data-live-post="/edit" data-live-context='{"view": ...}'>      the endpoint, and what every post carries
       <input name="..." data-live='{"cell": ...}' value="123">          what this cell's post carries; name is its identity
   Post body: context + data-live + {"value": typed}, as JSON, with the X-Live: 1 header. Reply: {id: html}, as JSON. */
(function () {
  var queue = Promise.resolve(), going = 0;
  var FOCUSABLE = "input:not([type=hidden]), select, textarea, button, a[href]";
  function focusables(el) {
    return Array.prototype.filter.call(el.querySelectorAll(FOCUSABLE), function (e) { return !e.disabled && e.tabIndex !== -1; });
  }
  function swap(parts) {
    var a = document.activeElement, name = a && a.name, id = a && a.id;
    var half = a && "defaultValue" in a && a.value !== a.defaultValue ? a.value : null;
    var s0 = a && a.selectionStart, s1 = a && a.selectionEnd;
    // where the cursor sits inside a part that is about to be replaced: that part's id and the element's place in it
    var inPart = null, at = -1;
    if (a && a !== document.body) {
      Object.keys(parts).forEach(function (pid) {
        var p = document.getElementById(pid);
        if (!inPart && p && p.contains(a)) { inPart = pid; at = focusables(p).indexOf(a); }
      });
    }
    Object.keys(parts).forEach(function (pid) {            // each part is parsed where it sits: a table body inside its
      var old = document.getElementById(pid);              // table, which a detached fragment would silently drop
      if (old) old.outerHTML = parts[pid];
    });
    if (!a || a === document.body || document.contains(a)) return;   // the cursor's element was not repainted
    var b = (name && document.querySelector('[name="' + CSS.escape(name) + '"]')) || (id && document.getElementById(id)) || null;
    if (!b && inPart) {
      var p = document.getElementById(inPart), f = p ? focusables(p) : [];
      b = at >= 0 && at < f.length ? f[at] : (f[0] || null);
    }
    if (!b) return;
    if (half !== null && "value" in b) b.value = half;
    b.focus();
    try { b.setSelectionRange(s0, s1); } catch (e) {}
  }
  function send(root, input) {
    if (input.value === input.defaultValue) return;
    var body = Object.assign({}, JSON.parse(root.dataset.liveContext || "{}"), JSON.parse(input.dataset.live), { value: input.value });
    input.defaultValue = input.value;                       // sent once: leaving the cell after Enter sends nothing more
    going++;
    queue = queue.then(function () {
      root.classList.add("live-busy");
      return fetch(root.dataset.livePost, { method: "POST", headers: { "Content-Type": "application/json", "X-Live": "1" }, body: JSON.stringify(body) })
        .then(function (r) { return r.json(); }).then(swap)
        .catch(function () { input.classList.add("live-failed"); })
        .then(function () { root.classList.remove("live-busy"); going--; });
    });
  }
  var roots = document.querySelectorAll("[data-live-post]");
  roots.forEach(function (root) {
    root.addEventListener("keydown", function (e) {
      var i = e.target;
      if (!i.matches("input[data-live]")) return;
      if (e.key === "Enter") { e.preventDefault(); send(root, i); i.select(); }
      else if (e.key === "Escape") { i.value = i.defaultValue; }
    });
    root.addEventListener("change", function (e) { if (e.target.matches("input[data-live]")) send(root, e.target); });
  });
  if (!roots.length) return;
  // a form leaves only once every typed cell has been sent and answered
  document.addEventListener("submit", function (e) {
    var form = e.target;
    if (form.dataset.liveFlushed) return;
    var dirty = [];
    roots.forEach(function (root) {
      root.querySelectorAll("input[data-live]").forEach(function (i) { if (i.value !== i.defaultValue) dirty.push([root, i]); });
    });
    if (!dirty.length && !going) return;
    e.preventDefault();
    var by = e.submitter || null, byName = by && by.name, byAction = by && by.getAttribute("formaction"), formId = form.id;
    dirty.forEach(function (d) { send(d[0], d[1]); });
    queue.then(function () {
      var f = form.isConnected ? form : (formId && document.getElementById(formId));
      if (!f) return;
      var s = by && by.isConnected ? by : null;
      if (!s && (byName || byAction)) s = Array.prototype.find.call(f.querySelectorAll("button, input[type=submit]"), function (x) {
        return (byName && x.name === byName) || (byAction && x.getAttribute("formaction") === byAction);
      }) || null;
      f.dataset.liveFlushed = "1";
      if (f.requestSubmit) f.requestSubmit(s || undefined); else f.submit();
    });
  }, true);
})();
