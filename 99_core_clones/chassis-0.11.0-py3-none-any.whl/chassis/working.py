"""Typing into a view without a run: a person's working copy, held in the face's memory until they save or discard it,
and the reply that repaints only the parts of the view an edit changed.

    COPIES = Copies()
    wc = COPIES.open(who, ("finance", version), make)     # get, or make it on the first edit
    COPIES.get(who, key)  ·  COPIES.drop(who, key)  ·  COPIES.held(who)
    with COPIES.lock(who): ...                             # one person's edits apply one at a time

The copy itself is the build's object — the chassis keeps it per person and per view and never hands one person's to
another. Plain Python in one process: a restart loses every copy, by design. A copy is a draft; the landing is the
record, and nothing reaches it until the build's save writes a file.

The edit endpoint (static/live.js posts one cell; the reply is the changed parts):

    before = parts()                  # {element id: html} of the view as it stands
    ...apply the one edit to the copy...
    return reply(before, parts())     # only the parts whose html changed, each carrying its id

On the page, `script()` is the tag for the script, and a container declares where edits go:

    <div data-live-post="/edit" data-live-context='{"view": ...}'>
      <input name="..." data-live='{"cell": ...}' value="123">

The post is the context, the input's data-live and {"value": typed} as JSON, with the `X-Live` header; `is_live()` tells
the endpoint it came from the script, so the same endpoint can serve a plain form post from a browser without it.
"""
from __future__ import annotations

import json
import threading
from typing import Callable, Hashable

from flask import Response, request, url_for
from markupsafe import Markup

HEADER = "X-Live"


class Copies:
    def __init__(self) -> None:
        self._held: dict[tuple[str, Hashable], object] = {}
        self._locks: dict[str, threading.RLock] = {}
        self._guard = threading.Lock()

    def get(self, who: str, key: Hashable):
        return self._held.get((who, key))

    def open(self, who: str, key: Hashable, make: Callable[[], object]):
        with self._guard:
            if (who, key) not in self._held:
                self._held[(who, key)] = make()
            return self._held[(who, key)]

    def drop(self, who: str, key: Hashable) -> bool:
        with self._guard:
            return self._held.pop((who, key), None) is not None

    def held(self, who: str) -> list[Hashable]:
        with self._guard:
            return [k for w, k in self._held if w == who]

    def lock(self, who: str) -> threading.RLock:
        with self._guard:
            return self._locks.setdefault(who, threading.RLock())


def is_live() -> bool:
    return request.headers.get(HEADER) == "1"


def changed(before: dict[str, str], after: dict[str, str]) -> dict[str, str]:
    """The parts whose html differs, in the order of `after`."""
    return {k: v for k, v in after.items() if before.get(k) != v}


def reply(before: dict[str, str], after: dict[str, str], always: tuple[str, ...] = ()) -> Response:
    """The changed parts as {id: html}; each part's outer element carries its id, and the script swaps it where it sits.
    `always` names parts sent whether or not they changed (a message, the cell that was refused)."""
    out = changed(before, after)
    for k in always:
        if k in after:
            out[k] = after[k]
    return Response(json.dumps(out), mimetype="application/json", headers={"X-Live-Parts": ",".join(out)})


def script() -> Markup:
    return Markup(f'<script src="{url_for("static", filename="live.js")}"></script>')
