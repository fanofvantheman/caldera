"""The page shell every face shares: one stylesheet, one two-level navigation, one vocabulary. A page is a body; the
shell is here. Top level: the areas of the product. Second level, in the sidebar: every area; the one you are in stays
open; another unfolds on a slowed hover, or stays open once its label is clicked. A page names its section; the area
follows.

A build declares its shell once:

    SHELL = Shell(brand="Caldera", strapline="integrated planning", home="plan",
                  nav=[("plan", "Plan", [("demand", "Demand plan", "plan", {}), ...]), ...],
                  who="select")          # "select": a demo room chooses who it acts as; "label": the room knows

and renders a page with `SHELL.page(body, title=..., active=<section key>, who=..., flash=...)`.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from flask import render_template_string, url_for

# area key, label, sections: (section key, label, endpoint, endpoint args)
Nav = list[tuple[str, str, list[tuple[str, str, str, dict]]]]

HEAD = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }} — {{ shell.brand }}</title><link rel="stylesheet" href="{{ url_for('static', filename='face.css') }}"></head>
<body><header class="top"><a class="brand" href="{{ url_for(shell.home) }}">{{ shell.brand }}<small>{{ shell.strapline }}</small></a>
<nav class="areas">{% for a in nav.areas %}<a href="{{ a.href }}" class="{{ 'active' if a.active }}">{{ a.label }}</a>{% endfor %}</nav>
{% if shell.who == 'select' and principals %}<form class="who" method="post" action="{{ url_for(shell.whoami) }}"><label>acting as</label>
<select name="who" onchange="this.form.submit()">{% for p in principals %}<option value="{{ p }}" {{ 'selected' if p == who }}>{{ p }}</option>{% endfor %}</select>
<input type="hidden" name="next" value="{{ request.path }}"></form>
{% else %}<span class="who">{% if who %}signed in as <b>{{ who }}</b>{% endif %}</span>{% endif %}</header>
<div class="shell"><aside class="side">
<nav>{% for g in nav.groups %}<div class="area {{ 'active' if g.active }}"><button type="button" class="group" onclick="this.parentNode.classList.toggle('open')">{{ g.label }}</button>
<div class="sections">{% for s in g.sections %}<a href="{{ s.href }}" class="{{ 'active' if s.active }}">{{ s.label }}</a>{% endfor %}</div></div>{% endfor %}</nav>
</aside>
<main{% if width %} style="--width:{{ width }}"{% endif %}>{% if flash %}<div class="flash {{ 'bad' if not flash.ok }}">{{ flash.says }}</div>{% endif %}
"""
FOOT = """
</main></div></body></html>"""


@dataclass
class Shell:
    brand: str
    strapline: str
    home: str                      # endpoint of the wordmark's link
    nav: Nav = field(default_factory=list)
    who: str = "label"             # "label" | "select"
    whoami: str = "whoami"         # endpoint the acting-as selector posts to, when who == "select"

    def _nav(self, active: str | None) -> dict:
        area_of = {sk: ak for ak, _, secs in self.nav for sk, *_ in secs}
        area = area_of.get(active or "", self.nav[0][0] if self.nav else "")
        areas = [dict(key=ak, label=al, href=url_for(secs[0][2], **secs[0][3]), active=ak == area) for ak, al, secs in self.nav]
        groups = [dict(key=ak, label=al, active=ak == area,
                       sections=[dict(key=sk, label=sl, href=url_for(ep, **args), active=sk == active) for sk, sl, ep, args in secs])
                  for ak, al, secs in self.nav]
        return dict(areas=areas, groups=groups)

    def page(self, body: str, **ctx) -> str:
        for k in ("who", "width", "active", "flash", "principals"):
            ctx.setdefault(k, None)
        ctx["nav"] = self._nav(ctx["active"])
        ctx["shell"] = self
        return render_template_string(HEAD + body + FOOT, **ctx)
