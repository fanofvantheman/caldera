"""The role register projected onto a face: who may do what, where, as at when. The register is right; the face asks it.

Two backends, one question. `WarehouseRoles` reads `dims.effective_entitlements` as the last run left it — the usual
case, and the only one when scope is many hierarchies. `FileRoles` judges from the register files themselves, for a
face that must decide before any run has happened (a door on day one); it takes the build's own `scope_ancestors`
so the chassis never learns which hierarchy a scope lives in.

The contract both answer:
    principals()                       -> every principal with an assignment
    may(who, action, scope=None, as_at=None) -> bool    scope is the build's node key (or None for 'anywhere')
    actions_held(who, as_at=None)      -> {action}      every verb held anywhere; routes worklists
"""
from __future__ import annotations

import csv
import datetime as dt
import pathlib
from typing import Callable, Protocol


def _today() -> str:
    return dt.date.today().isoformat()


class Roles(Protocol):
    def principals(self) -> list[str]: ...
    def may(self, who: str, action: str, scope: str | None = None, as_at: str | None = None) -> bool: ...
    def actions_held(self, who: str, as_at: str | None = None) -> set[str]: ...


class WarehouseRoles:
    """Over `dims.effective_entitlements` (principal, action, scope_node[, scope_dimension], valid_from, valid_to).
    If the surface carries no validity columns, as_at is ignored and the surface is read as 'today'."""

    def __init__(self, q: Callable[..., list[dict]], surface: str = "dims.effective_entitlements",
                 assignments: str = "dims.ctl_role_assignment"):
        self.q, self.surface, self.assignments = q, surface, assignments
        self._validity: bool | None = None

    def _has_validity(self) -> bool:
        if self._validity is None:
            schema, _, table = self.surface.partition(".")
            cols = {r["column_name"] for r in self.q(
                "select column_name from information_schema.columns where table_schema = ? and table_name = ?", schema, table)}
            self._validity = {"valid_from", "valid_to"} <= cols
        return self._validity

    def _as_at(self, as_at: str | None) -> str:
        return " and (valid_from is null or valid_from <= ?) and (valid_to is null or valid_to >= ?)" if self._has_validity() else ""

    def principals(self) -> list[str]:
        return [r["principal"] for r in self.q(f"select distinct principal from {self.assignments} order by 1")]

    def may(self, who: str, action: str, scope: str | None = None, as_at: str | None = None) -> bool:
        d = as_at or _today()
        sql = f"select 1 as ok from {self.surface} where principal = ? and action = ?" + (" and scope_node = ?" if scope else "")
        params: list = [who, action] + ([scope] if scope else [])
        if self._has_validity():
            sql += " and (valid_from is null or valid_from <= ?) and (valid_to is null or valid_to >= ?)"; params += [d, d]
        return bool(self.q(sql + " limit 1", *params))

    def actions_held(self, who: str, as_at: str | None = None) -> set[str]:
        d = as_at or _today()
        sql = f"select distinct action from {self.surface} where principal = ?"; params: list = [who]
        if self._has_validity():
            sql += " and (valid_from is null or valid_from <= ?) and (valid_to is null or valid_to >= ?)"; params += [d, d]
        return {r["action"] for r in self.q(sql, *params)}

    def layers_enterable(self, who: str, verb_pattern: str = r"layer\.([1-9])\.enter") -> list[int]:
        """A planning convenience: the layer numbers whose enter verb this person holds."""
        import re
        return sorted({int(m.group(1)) for a in self.actions_held(who) if (m := re.fullmatch(verb_pattern, a))})


class FileRoles:
    """Over the register files: ctl_role_assignment.csv (principal, role_code, scope_node, valid_from, valid_to) and
    ctl_role_action.csv (role_code, action). `scope_ancestors(node)` returns the node and every ancestor up to the root,
    in the build's own hierarchy; the chassis does not know which."""

    def __init__(self, reference: pathlib.Path, scope_ancestors: Callable[[str], list[str]]):
        self.reference, self.scope_ancestors = pathlib.Path(reference), scope_ancestors

    def _csv(self, name: str) -> list[dict]:
        p = self.reference / f"{name}.csv"
        if not p.exists():
            return []
        with p.open(newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    @staticmethod
    def _live(a: dict, as_at: str) -> bool:
        return not (a.get("valid_from") and a["valid_from"] > as_at) and not (a.get("valid_to") and a["valid_to"] < as_at)

    def principals(self) -> list[str]:
        return sorted({a["principal"] for a in self._csv("ctl_role_assignment")})

    def _actions(self) -> dict[str, set[str]]:
        out: dict[str, set[str]] = {}
        for r in self._csv("ctl_role_action"):
            out.setdefault(r["role_code"], set()).add(r["action"])
        return out

    def may(self, who: str, action: str, scope: str | None = None, as_at: str | None = None) -> bool:
        d = as_at or _today(); actions = self._actions()
        chain = set(self.scope_ancestors(scope)) if scope else None
        for a in self._csv("ctl_role_assignment"):
            if a["principal"] != who or action not in actions.get(a["role_code"], ()) or not self._live(a, d):
                continue
            if chain is None or a["scope_node"] in chain:
                return True
        return False

    def actions_held(self, who: str, as_at: str | None = None) -> set[str]:
        d = as_at or _today(); actions = self._actions(); held: set[str] = set()
        for a in self._csv("ctl_role_assignment"):
            if a["principal"] == who and self._live(a, d):
                held |= actions.get(a["role_code"], set())
        return held
