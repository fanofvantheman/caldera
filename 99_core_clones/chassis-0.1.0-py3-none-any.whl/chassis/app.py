"""The Flask app a face runs in: the chassis's stylesheet served as /static/face.css, the build's blueprints registered,
the acting-as selector's endpoint when the shell has one, and the reloader watching the build's own face folder.

    app = create_app(shell, session, roles, blueprints=[plan, registers])
    serve(app, port=8010, watch=Path(__file__).parent)
"""
from __future__ import annotations

import pathlib
import sys

from flask import Flask, redirect, request

from .roles import Roles
from .session import Session
from .ui import Shell

STATIC = pathlib.Path(__file__).parent / "static"


def create_app(shell: Shell, session: Session, roles: Roles, blueprints: list = (), import_name: str = "face") -> Flask:
    app = Flask(import_name, static_folder=str(STATIC), static_url_path="/static")
    for bp in blueprints:
        app.register_blueprint(bp)
    if shell.who == "select":
        def whoami():
            who = request.form.get("who", "")
            if who in roles.principals():
                session.become(who)
            return redirect(request.form.get("next") or "/")
        app.add_url_rule(f"/{shell.whoami}", endpoint=shell.whoami, view_func=whoami, methods=["POST"])
    return app


def serve(app: Flask, port: int = 8008, watch: pathlib.Path | None = None, argv: list[str] | None = None) -> None:
    """Reloads on changes under `watch` and to the chassis stylesheet; `--no-reload` on the command line for the room."""
    args = argv if argv is not None else sys.argv[1:]
    reload = "--no-reload" not in args
    extra = [str(STATIC / "face.css")]
    if watch:
        extra += [str(p) for p in pathlib.Path(watch).rglob("*.py")]
    app.run(port=port, debug=False, use_reloader=reload, extra_files=extra if reload else None)
