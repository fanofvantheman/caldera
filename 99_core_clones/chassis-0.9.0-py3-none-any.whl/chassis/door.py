"""Doors: where something made elsewhere comes into a build — a promotions export, a forecasting run, a file from a
ledger — is taken in, read against the build's own structures, and every disagreement is decided by a recorded act from
a declared list. One model for every door, in six parts:

  arrival       the unit taken in and replaced (an event, a run, a file) — the build's own
  declaration   what an arrival must say about itself to be let in — `Declaration`s, checked as data by `declared()`
  item          one disagreement, at the thing that disagrees, never the row — a row of the build's queue, in the
                columns of `QUEUE_COLUMNS`
  kind          for each kind of item, what a person may decide — `Kind` → `Resolution`s, held as reference data in the
                columns of `RESOLUTION_COLUMNS`
  meanwhile     what the build does with an undecided item — never a silent zero, never a block; said on the item
  act           one row per decision in a log register (`ACT_COLUMNS`): who, why, when; the latest act per item is in
                force and stands for later arrivals until someone acts again

What the chassis does not know is the comparison itself: which codes, series or members disagree, and what each would
bring, is the build's query over its own structures. A third door costs that query and a few rows of reference data.

    ACTS = LogLanding("plan", "reg_door_act", door.ACT_COLUMNS)
    FCS = Door("FCS", "the forecasting system", ACTS, kinds=lambda: door.kinds_from(q("select * from plan.ref_door_resolution"))["FCS"])
    checks = door.declared(RUN_DECLARATIONS, header, rows)                  # the take-in's declaration checks
    items = FCS.offer(q("select * from plan.worklist_forecast_queue"), who, may)   # each item with what this person may decide
    r = FCS.decide(who=who, kind=..., item_code=..., scope_code=..., resolution=..., target=..., reason=...,
                   waiting=row, ours=lambda names: {...}, may=may)              # checks, the act, the receipt

`QUEUE` and `DECIDED` are page components (template text) a build places in its own page; they read `door_items`,
`door_kinds`, `door_action`, `door_next`, `door_ours` and `door_decided`.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Callable

from . import receipts
from .landing import LogLanding

ACT_COLUMNS = ["act_id", "door", "kind", "item_code", "scope_code", "resolution", "target_code", "state", "origin",
               "confidence", "rationale", "item_description", "reason", "acted_by", "acted_at"]
# what a build's queue surface carries, one row per undecided item: `reaches` is the nodes whose holders may decide it
# (comma-separated; empty means anyone holding the verb), `whose` who it is routed to
QUEUE_COLUMNS = ["door", "kind", "item_code", "scope_code", "reaches", "description", "as_sent", "would_bring", "meanwhile",
                 "proposed_target", "proposal", "whose", "item"]
RESOLUTION_COLUMNS = ["door", "kind", "kind_says", "meanwhile", "resolution", "label", "says", "names", "takes_proposal",
                      "reason_required", "verb", "ord"]
STATE_PROPOSED, STATE_DECIDED = "proposed", "decided"
PROPOSE = "propose"                     # the resolution a proposal carries; it is never in force


@dataclass
class Resolution:
    key: str
    label: str                          # what the choice says before it is made
    says: str                           # what it says once made
    verb: str                           # the verb that lets a person make it
    names: str | None = None            # what of ours it names (a material, a product, a promo group …), or nothing
    takes_proposal: bool = False        # the target is the item's proposal — accepting it
    reason_required: bool = True


@dataclass
class Kind:
    key: str
    says: str
    meanwhile: str
    resolutions: list[Resolution] = field(default_factory=list)

    def get(self, key: str) -> Resolution | None:
        return next((r for r in self.resolutions if r.key == key), None)

    @property
    def names(self) -> list[str]:
        return sorted({r.names for r in self.resolutions if r.names})


def _true(x) -> bool:
    return x is True or str(x).strip().lower() in ("true", "y", "yes", "1")


def kinds_from(rows: list[dict]) -> dict[str, dict[str, Kind]]:
    """The reference table (`RESOLUTION_COLUMNS`, one row per door × kind × resolution) as door → kind → Kind, in order."""
    out: dict[str, dict[str, Kind]] = {}
    for r in sorted(rows, key=lambda r: (r["door"], int(r.get("ord") or 0))):
        k = out.setdefault(r["door"], {}).setdefault(r["kind"], Kind(r["kind"], r["kind_says"], r["meanwhile"]))
        k.resolutions.append(Resolution(r["resolution"], r["label"], r["says"], r["verb"], r.get("names") or None,
                                        _true(r.get("takes_proposal")), _true(r.get("reason_required", True))))
    return out


@dataclass
class Declaration:
    """One thing an arrival must say about itself. `holds(header, rows)`; `ok` / `no` are what the check says either way
    (text, or a function of header and rows). A flagged declaration is told, not refused."""
    check: str
    holds: Callable[[dict, list[dict]], bool]
    ok: str | Callable[[dict, list[dict]], str]
    no: str | Callable[[dict, list[dict]], str]
    flag: bool = False


def declared(declarations: list[Declaration], header: dict, rows: list[dict]) -> list[dict]:
    """The take-in's declaration checks, as receipt checks."""
    out = []
    for d in declarations:
        try:
            ok = bool(d.holds(header or {}, rows or []))
        except (KeyError, TypeError, ValueError):
            ok = False
        say = d.ok if ok else d.no
        out.append({"check": d.check, "ok": ok, "says": say(header or {}, rows or []) if callable(say) else say, **({"flag": True} if d.flag else {})})
    return out


def _reaches(row: dict | None) -> list[str]:
    return [x.strip() for x in str((row or {}).get("reaches") or "").split(",") if x.strip()]


class Door:
    """One door's acts: what may be decided about its items, the decision as a checked act with its receipt, proposals,
    and the latest act per item. `kinds` is called when needed (the reference table is read from the last run);
    `master` gives the act rows loaded with the build, before any the face placed."""

    def __init__(self, key: str, label: str, acts: LogLanding, kinds: Callable[[], dict[str, Kind]],
                 master: Callable[[], list[dict]] | None = None):
        self.key, self.label, self.acts, self._kinds, self._master = key, label, acts, kinds, master

    @property
    def kinds(self) -> dict[str, Kind]:
        return self._kinds()

    def history(self) -> list[dict]:
        """Every act of this door in time order: the build's master, then every act the face placed."""
        rows = (self._master() if self._master else []) + self.acts.rows()
        return [r for r in rows if r.get("door") == self.key]

    def latest(self) -> dict[tuple[str, str, str], dict]:
        """The latest act per (kind, item, scope) — what the next run will hold in force, proposals included."""
        out: dict[tuple[str, str, str], dict] = {}
        for r in sorted(self.history(), key=lambda r: r.get("acted_at") or ""):
            out[(r["kind"], r["item_code"], r.get("scope_code") or "ALL")] = r
        return out

    def known(self) -> set[tuple[str, str, str]]:
        return set(self.latest())

    def _row(self, kind: str, item: str, scope: str, resolution: str, target: str, state: str, origin: str, who: str,
             reason: str = "", description: str = "", confidence: str = "", rationale: str = "", n: int = 0) -> dict:
        now = dt.datetime.now()
        return {"act_id": f"DA-{self.key}-{now.strftime('%Y%m%d-%H%M%S-%f')}-{n:03d}", "door": self.key, "kind": kind, "item_code": item,
                "scope_code": scope or "ALL", "resolution": resolution, "target_code": target or "", "state": state, "origin": origin,
                "confidence": confidence, "rationale": rationale, "item_description": description, "reason": reason,
                "acted_by": who, "acted_at": now.isoformat(timespec="seconds")}

    def propose(self, proposals: list[dict], who: str, origin: str = "first_pass") -> int:
        """Proposed acts on items — {kind, item_code, scope_code?, target_code, confidence?, rationale?, item_description?} —
        never in force until a person takes one; one file for the set."""
        rows = [self._row(p["kind"], p["item_code"], p.get("scope_code") or "ALL", PROPOSE, p.get("target_code", ""), STATE_PROPOSED, origin, who,
                          description=p.get("item_description", ""), confidence=p.get("confidence", ""), rationale=p.get("rationale", ""), n=i)
                for i, p in enumerate(proposals, start=1)]
        if rows:
            self.acts.place(rows, who)
        return len(rows)

    def offer(self, items: list[dict], who: str, may: Callable[[str, str, list[str]], bool]) -> list[dict]:
        """Each queue item with `offers`: the resolutions of its kind this person may take, given who may decide it."""
        kinds = self.kinds
        out = []
        for i in items:
            k = kinds.get(i.get("kind"))
            offers = [r for r in (k.resolutions if k else []) if may(who, r.verb, _reaches(i)) and (not r.takes_proposal or i.get("proposed_target"))]
            out.append({**i, "offers": [{"key": r.key, "label": r.label + (f" {i['proposed_target']}" if r.takes_proposal else ""), "names": r.names,
                                         "takes_proposal": r.takes_proposal, "reason_required": r.reason_required} for r in offers]})
        return out

    def decide(self, *, who: str, kind: str, item_code: str, scope_code: str, resolution: str, target: str, reason: str,
               waiting: dict | None, ours: Callable[[str], set[str]], may: Callable[[str, str, list[str]], bool]) -> dict:
        """One decision about one item: checked, placed as one act, receipted. Returns {placed, checks, says, receipt, target}."""
        k = self.kinds.get(kind)
        r = k.get(resolution) if k else None
        target, reason = (target or "").strip(), (reason or "").strip()
        if r and r.takes_proposal:
            target = (waiting or {}).get("proposed_target") or ""
        reaches = _reaches(waiting)
        verbs = [r.verb] if r else sorted({x.verb for x in (k.resolutions if k else [])})
        holds = any(may(who, v, reaches) for v in verbs)
        where = f" at {', '.join(reaches)}" if reaches else ""
        known = ours(r.names) if r and r.names else set()
        checks = [
            {"check": "who may decide", "ok": holds, "says": f"{who} holds {' or '.join(verbs)}{where}" if holds
                else f"{who} does not hold {' or '.join(verbs) or 'a verb for this kind'}{where} — it is routed to {(waiting or {}).get('whose') or 'its owner'}"},
            {"check": "item waiting", "ok": waiting is not None, "says": f"{item_code} — {k.says if k else kind}" if waiting else f"{item_code} is not waiting for a decision"},
            {"check": "a decision this kind allows", "ok": r is not None, "says": r.says if r else f"{resolution or 'nothing'} is not a decision for this kind"},
        ]
        if r and r.takes_proposal:
            checks.append({"check": "a proposal to take", "ok": bool(target), "says": f"proposed {target}" if target else "nothing proposed — choose one of ours instead"})
        if r and r.names:
            checks.append({"check": "names one of ours", "ok": target in known, "says": f"{target} is one of our {r.names}s" if target in known else f"{target or 'nothing'} is not one of our {r.names}s"})
        if r is None or r.reason_required:
            checks.append({"check": "a reason says why", "ok": bool(reason), "says": reason or "a decision says why"})
        placed = receipts.judge(checks)
        if placed:
            self.acts.place([self._row(kind, item_code, scope_code, resolution, target if (r.names or r.takes_proposal) else "", STATE_DECIDED, "person", who,
                                       reason=reason, description=(waiting or {}).get("description") or "",
                                       confidence=(waiting or {}).get("confidence") or "", rationale=(waiting or {}).get("rationale") or "")], who)
        receipt = receipts.write(f"{self.key.lower()}.decide", who, f"{kind}:{item_code}@{scope_code or 'ALL'}", checks, placed)
        says = (f"{item_code}: {r.says}{' ' + target if target and (r.names or r.takes_proposal) else ''} — in the plan after the next run" if placed
                else "decision refused: " + "; ".join(c["says"] for c in checks if not c["ok"]))
        return {"placed": placed, "checks": checks, "says": says, "receipt": receipt, "target": target}


# ---- page components: template text a build places in its own page ----
QUEUE = """{% set by_kind = {} %}{% for i in door_items %}{% set _ = by_kind.setdefault(i.kind, []).append(i) %}{% endfor %}
{% for kkey, k in door_kinds.items() %}{% if by_kind.get(kkey) %}{% set items = by_kind[kkey] %}
<h3 class="door-kind">{{ k.says }}<span class="count">{{ items|length }} item{{ '' if items|length == 1 else 's' }} · meanwhile {{ k.meanwhile }}</span></h3>
<table class="door-queue"><thead><tr><th>Item</th><th>Where</th><th>As sent</th><th>Would bring</th><th>Meanwhile</th><th>Proposed</th><th>Decide</th></tr></thead><tbody>
{% for i in items %}<tr id="{{ i.kind }}-{{ i.item_code }}-{{ i.scope_code }}"><td><code>{{ i.item_code }}</code>{% if i.description %}<div class="small">{{ i.description }}</div>{% endif %}</td>
<td>{{ i.reaches or i.scope_code if (i.reaches or i.scope_code) != 'ALL' else 'all' }}</td><td class="small">{{ i.as_sent or '' }}</td><td class="small">{{ i.would_bring or '' }}</td>
<td class="small">{{ i.meanwhile or k.meanwhile }}</td><td class="small">{% if i.proposed_target %}<b>{{ i.proposed_target }}</b>{% endif %}{% if i.proposal %}<div class="muted">{{ i.proposal }}</div>{% endif %}</td>
<td class="acts">{% if i.offers %}<form class="inline" method="post" action="{{ door_action }}"><input type="hidden" name="kind" value="{{ i.kind }}"><input type="hidden" name="item_code" value="{{ i.item_code }}">
<input type="hidden" name="scope_code" value="{{ i.scope_code }}"><input type="hidden" name="next" value="{{ door_next }}">
<select name="resolution">{% for o in i.offers %}<option value="{{ o.key }}">{{ o.label }}</option>{% endfor %}</select>
{% if k.names %}<input name="target_code" list="door-ours-{{ kkey }}" placeholder="one of ours, if it names one" size="20">{% endif %}
<input name="reason" placeholder="why" size="14"> <button class="act">Decide</button></form>
{% else %}<span class="small muted">{{ 'routed to ' ~ i.whose if i.whose else 'nobody holds it yet' }}</span>{% endif %}</td></tr>{% endfor %}
</tbody></table>{% if k.names %}<datalist id="door-ours-{{ kkey }}">{% for n in k.names %}{% for o in door_ours.get(n, []) %}<option value="{{ o.code }}">{{ o.label }}</option>{% endfor %}{% endfor %}</datalist>{% endif %}
{% endif %}{% endfor %}{% if not door_items %}<p class="muted">Nothing waits for a decision.</p>{% endif %}"""

DECIDED = """{% if door_decided %}<table class="door-decided"><thead><tr><th>What disagreed</th><th>Item</th><th>Where</th><th>Decision</th><th>Why</th><th>By</th><th>At</th></tr></thead><tbody>
{% for r in door_decided %}{% set k = door_kinds.get(r.kind) %}{% set res = k.get(r.resolution) if k else none %}
<tr><td>{{ k.says if k else r.kind }}</td><td><code>{{ r.item_code }}</code>{% if r.item_description %}<div class="small">{{ r.item_description }}</div>{% endif %}</td><td>{{ r.scope_code if r.scope_code != 'ALL' else 'all' }}</td>
<td>{{ res.says if res else r.resolution }}{% if r.target_code %} <code>{{ r.target_code }}</code>{% if r.target_name %} <span class="muted small">{{ r.target_name }}</span>{% endif %}{% endif %}{% if r.note %}<div class="small muted">{{ r.note }}</div>{% endif %}</td>
<td class="small">{{ r.reason or '' }}</td><td>{{ r.acted_by }}</td><td class="small">{{ r.acted_at }}</td></tr>{% endfor %}</tbody></table>
{% else %}<p class="muted">Nothing decided yet.</p>{% endif %}"""
