/* Typing into a view without a run (chassis.working). Enter, Tab or leaving an input posts that one cell; the reply is
   the parts of the view the edit changed, each an element with an id, swapped in place. The cursor stays where it is —
   Enter keeps it in the cell — and whatever is half-typed in the cell it is in survives the swap. Escape puts back the
   value shown. Posts go one at a time, in the order typed.

     <div data-live-post="/edit" data-live-context='{"view": ...}'>      the endpoint, and what every post carries
       <input name="..." data-live='{"cell": ...}' value="123">          what this cell's post carries; name is its identity
   Post body: context + data-live + {"value": typed}, as JSON, with the X-Live: 1 header. Reply: html. */
(function () {
  var queue = Promise.resolve();
  function swap(html) {
    var t = document.createElement("template"); t.innerHTML = html;
    var a = document.activeElement, name = a && a.name, half = a && a.value !== a.defaultValue ? a.value : null;
    var s0 = a && a.selectionStart, s1 = a && a.selectionEnd;
    Array.prototype.slice.call(t.content.children).forEach(function (el) {
      var old = el.id && document.getElementById(el.id);
      if (old) old.replaceWith(el);
    });
    if (!name) return;
    var b = document.querySelector('[name="' + CSS.escape(name) + '"]');
    if (!b || b === a) return;
    if (half !== null) b.value = half;
    b.focus();
    try { b.setSelectionRange(s0, s1); } catch (e) {}
  }
  function send(root, input) {
    if (input.value === input.defaultValue) return;
    var body = Object.assign({}, JSON.parse(root.dataset.liveContext || "{}"), JSON.parse(input.dataset.live), { value: input.value });
    input.defaultValue = input.value;                       // sent once: leaving the cell after Enter sends nothing more
    queue = queue.then(function () {
      root.classList.add("live-busy");
      return fetch(root.dataset.livePost, { method: "POST", headers: { "Content-Type": "application/json", "X-Live": "1" }, body: JSON.stringify(body) })
        .then(function (r) { return r.text(); }).then(swap)
        .catch(function () { input.classList.add("live-failed"); })
        .then(function () { root.classList.remove("live-busy"); });
    });
  }
  document.querySelectorAll("[data-live-post]").forEach(function (root) {
    root.addEventListener("keydown", function (e) {
      var i = e.target;
      if (!i.matches("input[data-live]")) return;
      if (e.key === "Enter") { e.preventDefault(); send(root, i); i.select(); }
      else if (e.key === "Escape") { i.value = i.defaultValue; }
    });
    root.addEventListener("change", function (e) { if (e.target.matches("input[data-live]")) send(root, e.target); });
  });
})();
