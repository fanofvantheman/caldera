/* Inputs directly into cells. A cell that carries data-cell is editable: click it, type the number you want, press
   Enter, give a reason, and the face posts an act. What the act is — an entry, a delta, an override — is the build's;
   this file only turns a cell into a small form and marks the cell pending until the next run shows the number.

   Table setup (the build's page):
     <table data-cells-post="/cell" data-cells-reasons="reasons">   the endpoint; the id of a <script type=application/json>
     <td data-cell='{"material": ..., "period": ...}' data-current="123.4">123</td>
   The post body is the cell's data-cell object plus {"current", "typed", "reason", "note"}; the reply is
   {"placed": bool, "says": str, "mark": str} — mark is written beside the cell as the pending change. */
(function () {
  function fmt(n) { return Number(n).toLocaleString(undefined, { maximumFractionDigits: 0 }); }
  document.querySelectorAll("table[data-cells-post]").forEach(function (table) {
    var post = table.dataset.cellsPost;
    var reasons = [];
    try { reasons = JSON.parse(document.getElementById(table.dataset.cellsReasons).textContent); } catch (e) {}
    table.addEventListener("click", function (ev) {
      var td = ev.target.closest("td[data-cell]");
      if (!td || td.querySelector("input")) return;
      var current = parseFloat(td.dataset.current || "0") || 0;
      var shown = td.textContent;
      td.classList.add("editing");
      td.innerHTML = '<input class="cell" type="number" step="any" value="' + Math.round(current) + '">';
      var input = td.querySelector("input"); input.focus(); input.select();
      function restore() { td.classList.remove("editing"); td.textContent = shown; }
      input.addEventListener("keydown", function (e) {
        if (e.key === "Escape") { restore(); }
        if (e.key === "Enter") { e.preventDefault(); ask(parseFloat(input.value)); }
      });
      input.addEventListener("blur", function () { setTimeout(function () { if (td.querySelector("input") === input) restore(); }, 150); });
      function ask(typed) {
        if (isNaN(typed) || Math.abs(typed - current) < 0.5) { restore(); return; }
        td.innerHTML = '<form class="cellform"><div class="delta">' + (typed > current ? "+" : "") + fmt(typed - current) + '</div>'
          + '<select name="reason">' + reasons.map(function (r) { return '<option value="' + r.code + '">' + r.code + " — " + r.says + "</option>"; }).join("") + '</select>'
          + '<input name="note" placeholder="note (optional)">'
          + '<div class="acts"><button type="submit" class="act primary">place</button> <button type="button" class="act cancel">cancel</button></div></form>';
        var form = td.querySelector("form");
        form.querySelector("select").focus();
        form.querySelector(".cancel").addEventListener("click", restore);
        form.addEventListener("submit", function (e) {
          e.preventDefault();
          var body = Object.assign({}, JSON.parse(td.dataset.cell), { current: current, typed: typed,
            reason: form.reason.value, note: form.note.value });
          fetch(post, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
              td.classList.remove("editing");
              td.innerHTML = shown + (res.placed ? '<span class="pending" title="' + res.says + '">' + res.mark + "</span>" : "");
              td.classList.toggle("refused", !res.placed);
              td.title = res.says;
              if (res.placed) td.classList.add("has-pending");
            })
            .catch(function () { restore(); });
        });
      }
    });
  });
})();
