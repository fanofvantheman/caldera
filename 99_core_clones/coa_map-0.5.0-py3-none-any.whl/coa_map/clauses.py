"""Read a collective instrument and propose its entitlements as rows under a closed list of kinds.

The third first pass of the tool, beside the chart of accounts (`coa_map.map`) and any subject's codes
(`coa_map.codes`): the same act — propose rows onto a closed list for a person to accept — with a document as the
source instead of a list of codes. Given

  document     the text of a collective instrument: an enterprise agreement, an award or a statute
  kinds        the closed list of kinds of entitlement the caller can price (code, description) — a base rate, a
               loading, an allowance, a leave accrual, an on-cost, a dated increase, a one-off payment, or whatever the
               caller's list holds
  classifications  the classifications a row may name (code, description); a row may name none (every classification)

returns, for every clause that grants an entitlement, a proposed row — the kind, the classification, the pattern of
work it applies to, the value, the date it runs from, the clause's reference and the clause quoted — with a confidence
and a one-line rationale; a clause the model places under no kind comes back unplaced, quoted, for a person to resolve.

Two checks are the code's, never the model's:

  the quotation   every quoted clause is looked for in the document, word for word (runs of whitespace read as one
                  space, nothing else forgiven); a row or an unplaced clause whose quotation is not found is refused —
                  returned under `refused` with the reason, never as a proposal
  the instrument  collective instruments only. An individual's contract of employment is refused before anything is
                  sent: pay that belongs to a named person does not go to a model.

The pass proposes; it never decides. A caller writes the proposals where a person accepts or alters each, and reads
only accepted rows. It is for pricing a roster in a plan, not for interpreting an instrument for payroll.

No credentials, a refusal or an API failure raise `MappingUnavailable` (from `coa_map.codes`) with a plain sentence;
nothing fails — the caller leaves the document waiting for a person.

Library use:

    from coa_map.clauses import propose_entitlements
    out = propose_entitlements(text, kinds=[{"code": "base_rate", "description": "a rate per hour by classification"}, ...],
                               classifications=[{"code": "PO1", "description": "Process operator grade 1"}, ...],
                               instrument="enterprise_agreement")
    out["rows"], out["unplaced"], out["refused"]

CLI:

    python -m coa_map.clauses --document agreement.txt --kinds kinds.csv [--classifications classes.csv] \\
        --instrument enterprise_agreement --output proposals.csv [--model MODEL]

  kinds.csv, classes.csv   columns code, description
  proposals.csv            columns placed, kind, classification, applies_to, value, from_date, clause_ref, quote,
                           confidence, rationale, refused_because — placed is row, unplaced or refused

The model defaults to `COA_MAP_MODEL` in the environment, else claude-opus-5-5.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from pathlib import Path

from .codes import CONFIDENCE, DEFAULT_MODEL, MappingUnavailable, credentials_present

INSTRUMENTS = ("enterprise_agreement", "award", "statute")
UNPLACED = "none"
COLUMNS = ["placed", "kind", "classification", "applies_to", "value", "from_date", "clause_ref", "quote", "confidence", "rationale", "refused_because"]

_SYSTEM = """\
You read a collective instrument of employment — an enterprise agreement, an award or a statute — and propose the
entitlements it grants as rows for a planning system that prices a roster. You are given the closed list of kinds of
entitlement the system can price (code | description), the classifications a row may name (code | description) and
the document.

For every clause that grants an entitlement, return one item:
  kind            one code from the list of kinds. If the clause grants something none of the kinds describes, use
                  "none" — never force it into a kind. A clause that grants nothing (definitions, procedure, consultation)
                  is not returned at all.
  classification  the classification code it applies to, or "" when it applies to every classification
  applies_to      the pattern of work or occasion it applies to, in one or two words ("casual", "afternoon shift",
                  "night shift", "weekend", "overtime", "annual leave", "meal") or "" when it applies to all ordinary hours
  value           the number the clause states: dollars for a rate or an amount, a fraction for a share (25% is 0.25);
                  0 when it states none
  from_date       the date it runs from as YYYY-MM-DD when the document states one, else ""
  clause_ref      the clause's number or schedule item as the document writes it
  quote           the words of the clause that grant it, copied exactly from the document — the system rejects any item
                  whose quote is not found in the document word for word
  confidence      "high" when the clause plainly states the kind and the value; "medium" when it is the likely reading;
                  "low" when the evidence is thin
  rationale       one short sentence a reviewer can check against the clause

A schedule of rates is one item per classification. Return the items in the order the clauses appear."""


class NotCollective(ValueError):
    """The document is not a collective instrument; nothing was sent."""


def normalise(text: str) -> str:
    """The document and a quotation as compared: runs of whitespace read as one space, nothing else changed."""
    return re.sub(r"\s+", " ", text or "").strip()


def quotation_found(quote: str, document: str) -> bool:
    """True when the quotation is in the document word for word — the code's check, not the model's."""
    q = normalise(quote)
    return bool(q) and q in normalise(document)


def _schema(kinds: list[str], classifications: list[str]) -> dict:
    return {
        "type": "object",
        "properties": {
            "clauses": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "kind": {"type": "string", "enum": kinds + [UNPLACED]},
                        "classification": {"type": "string", "enum": classifications + [""]},
                        "applies_to": {"type": "string"},
                        "value": {"type": "number"},
                        "from_date": {"type": "string"},
                        "clause_ref": {"type": "string"},
                        "quote": {"type": "string"},
                        "confidence": {"type": "string", "enum": list(CONFIDENCE)},
                        "rationale": {"type": "string"},
                    },
                    "required": ["kind", "classification", "applies_to", "value", "from_date", "clause_ref", "quote", "confidence", "rationale"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["clauses"],
        "additionalProperties": False,
    }


def _prompt(instrument: str, guidance: str, document: str, kinds: list[dict], classifications: list[dict]) -> str:
    k = "\n".join(f"  {r['code']} | {r.get('description') or ''}" for r in kinds)
    c = "\n".join(f"  {r['code']} | {r.get('description') or ''}" for r in classifications) or "  (none listed — use \"\")"
    g = f"\nGUIDANCE:\n{guidance}\n" if guidance else ""
    return (f"INSTRUMENT: {instrument.replace('_', ' ')}\n{g}\nKINDS (code | description):\n{k}\n\n"
            f"CLASSIFICATIONS (code | description):\n{c}\n\nDOCUMENT:\n<document>\n{document}\n</document>")


def judge(items: list[dict], document: str, kinds: list[str]) -> dict:
    """The model's items sorted by the code's checks: a row under a kind, a clause placed under no kind, or refused —
    a quotation not found in the document word for word, or a kind not on the list. Usable on its own."""
    out: dict[str, list[dict]] = {"rows": [], "unplaced": [], "refused": []}
    for it in items:
        it = {**it, "quote": (it.get("quote") or "").strip(), "rationale": (it.get("rationale") or "").strip()}
        if not quotation_found(it["quote"], document):
            out["refused"].append({**it, "refused_because": "the quoted clause is not in the document word for word"})
        elif it.get("kind") == UNPLACED:
            out["unplaced"].append(it)
        elif it.get("kind") not in kinds:
            out["refused"].append({**it, "refused_because": f"{it.get('kind') or 'no kind'} is not on the list of kinds"})
        else:
            out["rows"].append(it)
    return out


def propose_entitlements(document: str, kinds: list[dict], classifications: list[dict] | None = None,
                         instrument: str = "enterprise_agreement", guidance: str = "", *,
                         model: str | None = None, client=None, effort: str = "medium") -> dict:
    """Propose the entitlements a collective instrument grants. Returns {rows, unplaced, refused}. Raises NotCollective
    for anything but a collective instrument (before anything is sent), MappingUnavailable when the pass cannot run,
    ValueError on bad inputs."""
    if instrument not in INSTRUMENTS:
        raise NotCollective(f"{instrument or 'this document'} is not a collective instrument — the first pass reads "
                            f"{', '.join(i.replace('_', ' ') for i in INSTRUMENTS)} only; an individual's terms are not sent")
    if not normalise(document):
        raise ValueError("the document is empty")
    codes = [r["code"] for r in kinds]
    if not codes:
        raise ValueError("the list of kinds is empty")
    classifications = classifications or []
    if client is None and not credentials_present():
        raise MappingUnavailable("no API key in the environment — the first pass did not run")
    try:
        import anthropic
    except ImportError as e:                                    # pragma: no cover - a dependency of the wheel
        raise MappingUnavailable(f"the Anthropic SDK is not installed ({e})") from e
    client = client or anthropic.Anthropic()
    try:
        with client.messages.stream(
            model=model or os.environ.get("COA_MAP_MODEL") or DEFAULT_MODEL,
            max_tokens=32000,
            system=_SYSTEM,
            output_config={"effort": effort, "format": {"type": "json_schema", "schema": _schema(codes, [r["code"] for r in classifications])}},
            messages=[{"role": "user", "content": _prompt(instrument, guidance, document, kinds, classifications)}],
        ) as stream:
            msg = stream.get_final_message()
    except anthropic.APIConnectionError as e:
        raise MappingUnavailable(f"the service could not be reached ({e.__class__.__name__})") from e
    except anthropic.AuthenticationError as e:
        raise MappingUnavailable("the API key was refused — the first pass did not run") from e
    except anthropic.APIStatusError as e:
        raise MappingUnavailable(f"the service answered {e.status_code} — the first pass did not run") from e
    if msg.stop_reason == "refusal":
        raise MappingUnavailable("the service declined the request")
    if msg.stop_reason == "max_tokens":
        raise MappingUnavailable("the answer was cut off — give the document in parts")
    text = next((b.text for b in msg.content if b.type == "text"), "")
    try:
        items = json.loads(text)["clauses"]
    except (json.JSONDecodeError, KeyError, TypeError) as e:
        raise MappingUnavailable(f"the answer was not the shape asked for ({e})") from e
    items = [i for i in items if isinstance(i, dict) and i.get("confidence") in CONFIDENCE]
    return judge(items, document, codes)


def _read(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if rows and not {"code", "description"} <= set(rows[0]):
        raise ValueError(f"{path.name}: columns code and description are required; found {list(rows[0])}")
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(prog="coa-map-clauses", description="Propose a collective instrument's entitlements under a closed list of kinds, using Claude.")
    ap.add_argument("--document", required=True, metavar="TXT", help="the instrument's text")
    ap.add_argument("--kinds", required=True, metavar="CSV", help="the closed list of kinds: columns code, description")
    ap.add_argument("--classifications", metavar="CSV", help="the classifications a row may name: columns code, description")
    ap.add_argument("--instrument", default="enterprise_agreement", choices=INSTRUMENTS, help="what the document is (collective instruments only)")
    ap.add_argument("--guidance", default="", help="anything the reader should know, in a sentence or a paragraph")
    ap.add_argument("--output", required=True, metavar="CSV", help="proposals: " + ", ".join(COLUMNS))
    ap.add_argument("--model", default=None, help=f"Claude model id (default: $COA_MAP_MODEL, else {DEFAULT_MODEL})")
    args = ap.parse_args()
    try:
        text = Path(args.document).read_text(encoding="utf-8")
        out = propose_entitlements(text, _read(Path(args.kinds)), _read(Path(args.classifications)) if args.classifications else [],
                                   args.instrument, args.guidance, model=args.model)
    except (ValueError, OSError, MappingUnavailable) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    with Path(args.output).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        for placed, rows in (("row", out["rows"]), ("unplaced", out["unplaced"]), ("refused", out["refused"])):
            for r in rows:
                w.writerow({"placed": placed, **r})
    print(f"Proposed {len(out['rows'])} rows, {len(out['unplaced'])} clauses under no kind, {len(out['refused'])} refused → {args.output}")


if __name__ == "__main__":
    main()
