"""The page shell every face shares: one stylesheet, one navigation, one vocabulary. A page is a body; the shell is here.

The product is a list of **processes** (the register a build declares — a plan, a close, a financial plan). Each has
**areas**; each area has **sections**, which are pages. A section names the verbs that make it relevant; a person sees
the sections whose verbs they hold, the areas that still have a section, the processes that still have an area. The
role is the gateway: the same product shows a planner their layers and a reader the readings, and shows nobody a
process they do not touch. A section with no verbs is for everyone who can see the face at all.

Across the top: the processes this person reaches. Down the side: the active process's areas, the one you are in
open, another unfolding on a slowed hover or staying open once clicked — only the active context is in the sidebar; the
other processes are across the top. A page names its section; area and process follow. The home page's sidebar is the
person's workspace: the sections of the home page itself.

    SHELL = Shell(brand="Caldera", strapline="integrated planning", home="plan.home", who="select", processes=[
        Process("ibp", "Integrated planning", [
            Area("demand", "Demand", [Section("demand", "Demand plan", "plan.demand", verbs=["read.plan"]), ...]),
        ]),
    ])
    SHELL.page(body, title=..., active="demand", who=who, held=roles.actions_held(who), flash=..., principals=...)

A person chooses the face's colour scheme in the top bar. A scheme re-sets the stylesheet's colour tokens and nothing
else; the choice is kept per person in one browser cookie (a map of person → scheme), so the room remembers each person's
choice across restarts and switching who you act as switches the scheme with them. `Shell(schemes=...)` narrows or
renames the set; the keys must be schemes the stylesheet defines.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from urllib.parse import parse_qsl, urlencode

from flask import render_template_string, request, url_for

SCHEMES = [("paper", "Paper"), ("night", "Night"), ("slate", "Slate"), ("contrast", "Contrast")]
SCHEME_COOKIE = "face_schemes"


def schemes_chosen(cookie: str | None) -> dict[str, str]:
    """The cookie's person → scheme map; anything unreadable is no choice."""
    try:
        return dict(parse_qsl(cookie or "", keep_blank_values=True))
    except ValueError:
        return {}


def schemes_cookie(chosen: dict[str, str]) -> str:
    return urlencode(chosen)


@dataclass
class Section:
    key: str
    label: str
    endpoint: str
    args: dict = field(default_factory=dict)
    verbs: list[str] = field(default_factory=list)      # any one of these makes the section visible; none = everyone

    def visible(self, held: set[str] | None) -> bool:
        return held is None or not self.verbs or any(v in held for v in self.verbs)


@dataclass
class Area:
    key: str
    label: str
    sections: list[Section]

    def shown(self, held: set[str] | None) -> list[Section]:
        return [s for s in self.sections if s.visible(held)]


@dataclass
class Process:
    key: str
    label: str
    areas: list[Area]
    says: str = ""                                      # one line on what the process is, for a role's home page

    def shown(self, held: set[str] | None) -> list[tuple[Area, list[Section]]]:
        out = []
        for a in self.areas:
            secs = a.shown(held)
            if secs:
                out.append((a, secs))
        return out


HEAD = """<!doctype html><html lang="en" data-scheme="{{ scheme }}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }} — {{ shell.brand }}</title><link rel="stylesheet" href="{{ url_for('static', filename='face.css') }}"></head>
<body><header class="top"><a class="brand" href="{{ url_for(shell.home) }}">{{ shell.brand }}<small>{{ shell.strapline }}</small></a>
<nav class="areas">{% for p in nav.processes %}<a href="{{ p.href }}" class="{{ 'active' if p.active }}">{{ p.label }}</a>{% endfor %}</nav>
{% if shell.who == 'select' and principals %}<form class="who" method="post" action="{{ url_for(shell.whoami) }}"><a href="{{ url_for(shell.whoami) }}" title="change who you are">acting as</a>
<select name="who" onchange="this.form.submit()">{% for p in principals %}<option value="{{ p }}" {{ 'selected' if p == who }}>{{ p }}</option>{% endfor %}</select>
<input type="hidden" name="next" value="{{ request.path }}"></form>
{% else %}<span class="who">{% if who %}signed in as <b>{{ who }}</b>{% endif %}</span>{% endif %}
{% if shell.schemes|length > 1 %}<form class="scheme" method="post" action="{{ url_for(shell.scheme) }}"><label for="scheme">scheme</label>
<select id="scheme" name="scheme" onchange="this.form.submit()">{% for k, label in shell.schemes %}<option value="{{ k }}" {{ 'selected' if k == scheme }}>{{ label }}</option>{% endfor %}</select>
<input type="hidden" name="who" value="{{ who or '' }}"><input type="hidden" name="next" value="{{ request.full_path if request.query_string else request.path }}"><noscript><button>set</button></noscript></form>{% endif %}</header>
<div class="shell"><aside class="side">
<nav>{% for g in nav.groups %}<div class="area {{ 'active' if g.active }}"><button type="button" class="group" onclick="this.parentNode.classList.toggle('open')">{{ g.label }}</button>
<div class="sections">{% for s in g.sections %}<a href="{{ s.href }}" class="{{ 'active' if s.active }}">{{ s.label }}</a>{% endfor %}</div></div>{% endfor %}</nav>
</aside>
<main{% if width %} style="--width:{{ width }}"{% endif %}>{% if flash %}<div class="flash {{ 'bad' if not flash.ok }}">{{ flash.says }}</div>{% endif %}
"""
FOOT = """
</main></div></body></html>"""


@dataclass
class Shell:
    brand: str
    strapline: str
    home: str                      # endpoint of the wordmark's link — the role's home page
    processes: list[Process] = field(default_factory=list)
    who: str = "label"             # "label" | "select"
    whoami: str = "whoami"         # endpoint the acting-as selector posts to, when who == "select"
    workspace: list[tuple[str, str]] = field(default_factory=lambda: [("My attention", "#attention"), ("My planning", "#planning")])
                                   # the home page's own sections — what the sidebar shows there, since only the active context shows
    schemes: list[tuple[str, str]] = field(default_factory=lambda: list(SCHEMES))
                                   # the colour schemes a person may choose, the first the default; one entry hides the control
    scheme: str = "scheme"         # endpoint the scheme control posts to

    def scheme_of(self, who: str | None) -> str:
        """This person's chosen scheme, read from the request's cookie; the first scheme when none is chosen."""
        keys = [k for k, _ in self.schemes]
        chosen = schemes_chosen(request.cookies.get(SCHEME_COOKIE)).get(who or "")
        return chosen if chosen in keys else keys[0]

    def locate(self, section_key: str | None) -> tuple[Process | None, Area | None]:
        for p in self.processes:
            for a in p.areas:
                if any(s.key == section_key for s in a.sections):
                    return p, a
        return None, None

    def reach(self, held: set[str] | None) -> list[tuple[Process, list[tuple[Area, list[Section]]]]]:
        """What this person sees: every process with at least one visible area, each with its visible sections."""
        out = []
        for p in self.processes:
            areas = p.shown(held)
            if areas:
                out.append((p, areas))
        return out

    def _nav(self, active: str | None, held: set[str] | None) -> dict:
        proc, _ = self.locate(active)
        reach = self.reach(held)
        if proc is None and reach:
            proc = reach[0][0]
        processes = [dict(key=p.key, label=p.label, href=url_for(areas[0][1][0].endpoint, **areas[0][1][0].args), active=proc is not None and p.key == proc.key)
                     for p, areas in reach]
        groups = []
        if active is None:
            # the home page: only the active context shows, and here that is the person's own workspace
            groups.append(dict(key="workspace", label="My workspace", active=True,
                               sections=[dict(key=href, label=label, href=href, active=False) for label, href in self.workspace]))
            for pr in processes:
                pr["active"] = False
            return dict(processes=processes, groups=groups)
        for p, areas in reach:
            if proc is None or p.key != proc.key:
                continue
            for a, secs in areas:
                groups.append(dict(key=a.key, label=a.label, active=any(s.key == active for s in secs),
                                   sections=[dict(key=s.key, label=s.label, href=url_for(s.endpoint, **s.args), active=s.key == active) for s in secs]))
        return dict(processes=processes, groups=groups)

    def page(self, body: str, **ctx) -> str:
        for k in ("who", "width", "active", "flash", "principals", "held"):
            ctx.setdefault(k, None)
        ctx["nav"] = self._nav(ctx["active"], ctx["held"])
        ctx.setdefault("scheme", self.scheme_of(ctx["who"]))
        ctx["shell"] = self
        return render_template_string(HEAD + body + FOOT, **ctx)
