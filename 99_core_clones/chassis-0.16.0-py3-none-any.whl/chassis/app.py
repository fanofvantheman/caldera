"""The Flask app a face runs in: the chassis's stylesheet served as /static/face.css, the build's blueprints registered,
the acting-as selector's endpoint when the shell has one, the colour-scheme endpoint (the person's choice kept in a
cookie, per person), the shell's context carried on every address it builds, and the reloader watching the build's own
face folder.

    app = create_app(shell, session, roles, blueprints=[plan, registers])
    serve(app, port=8010, watch=Path(__file__).parent)
"""
from __future__ import annotations

import pathlib
import sys

from flask import Flask, has_request_context, redirect, request

from .roles import Roles
from .session import Session
from .ui import SCHEME_COOKIE, Shell, context_fields, schemes_chosen, schemes_cookie
from .warehouse import Busy

STATIC = pathlib.Path(__file__).parent / "static"

SIGN_IN = """<h1>Who are you today?<small>the roles a person holds decide what they see and may do — choose one to act as them</small></h1>
<div class="cards people">{% for p in people %}<form method="post" action="{{ url_for(shell.whoami) }}" class="card person {{ 'me' if p.principal == who }}">
<input type="hidden" name="who" value="{{ p.principal }}"><input type="hidden" name="next" value="{{ url_for(shell.home) }}">
<button class="{{ 'primary' if p.principal == who }}">{{ p.principal }}</button>
<ul>{% for r in p.roles %}<li><b>{{ r.role_name }}</b>{% if r.scope %} <span class="muted">{{ r.scope }}</span>{% endif %}{% if r.description %}<div class="small muted">{{ r.description }}</div>{% endif %}</li>{% endfor %}</ul>
</form>{% endfor %}</div>
<style>.people{grid-template-columns:repeat(auto-fill,minmax(300px,1fr))}.person ul{list-style:none;padding:0;margin:.8rem 0 0}.person li{padding:.35rem 0;border-top:1px solid var(--rule);font-size:.9rem}
.person button{width:100%;text-align:left;font-weight:600}.person.me{border-color:var(--accent)}</style>"""


def create_app(shell: Shell, session: Session, roles: Roles, blueprints: list = (), import_name: str = "face") -> Flask:
    app = Flask(import_name, static_folder=str(STATIC), static_url_path="/static")
    for bp in blueprints:
        app.register_blueprint(bp)
    keys = shell.context_keys()

    @app.url_defaults
    def carry_context(endpoint: str, values: dict) -> None:
        """Every address the face builds carries the context set in this one's — unless the caller names the key itself
        (None drops it) — and, from a page reached through a process (`via`), that process to every page it lists and to
        every address no process lists (a form's action, a redirect's target), never to another process's page."""
        if endpoint == "static" or not has_request_context():
            return
        for k in keys:
            if k not in values and request.args.get(k):
                values[k] = request.args[k]
        via = request.args.get("via")
        if via and "via" not in values and (shell.lists(via, request.endpoint) or not shell.listed(request.endpoint)) \
                and (shell.lists(via, endpoint) or not shell.listed(endpoint)):
            values["via"] = via
    app.jinja_env.globals["context_fields"] = lambda: context_fields(keys)
    def scheme():
        """Keep this person's scheme; an unknown scheme is ignored. Who is the person the page was rendered for."""
        nxt = request.form.get("next") or "/"
        resp = redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else "/")
        choice, who = request.form.get("scheme", ""), request.form.get("who", "")
        if choice in [k for k, _ in shell.schemes]:
            chosen = schemes_chosen(request.cookies.get(SCHEME_COOKIE))
            chosen[who] = choice
            resp.set_cookie(SCHEME_COOKIE, schemes_cookie(chosen), max_age=60 * 60 * 24 * 365, samesite="Lax", httponly=True)
        return resp
    app.add_url_rule(f"/{shell.scheme}", endpoint=shell.scheme, view_func=scheme, methods=["POST"])
    if shell.who == "select":
        def whoami():
            if request.method == "POST":
                who = request.form.get("who", "")
                if who in roles.principals():
                    session.become(who)
                return redirect(request.form.get("next") or "/")
            try:
                people = roles.people(); principals = [p["principal"] for p in people]
            except Busy as e:
                return shell.page(f"<h1>Who are you today?</h1><p class='lede'>{e}</p>", title="Sign in", principals=[])
            who = session.who(principals)
            return shell.page(SIGN_IN, title="Sign in", who=who, held=set(), principals=principals, people=people, active=None)
        app.add_url_rule(f"/{shell.whoami}", endpoint=shell.whoami, view_func=whoami, methods=["GET", "POST"])
    return app


def serve(app: Flask, port: int = 8008, watch: pathlib.Path | None = None, argv: list[str] | None = None) -> None:
    """Reloads on changes under `watch` and to the chassis stylesheet; `--no-reload` on the command line for the room."""
    args = argv if argv is not None else sys.argv[1:]
    reload = "--no-reload" not in args
    extra = [str(STATIC / "face.css")]
    if watch:
        extra += [str(p) for p in pathlib.Path(watch).rglob("*.py")]
    app.run(port=port, debug=False, use_reloader=reload, extra_files=extra if reload else None)
